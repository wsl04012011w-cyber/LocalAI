# Integração nativa `llama.cpp` — estado atual

Este documento substitui o antigo handoff. A engine JNI está integrada ao projeto; não é mais necessário substituir o `StubLlamaEngineAdapter` manualmente.

## Arquitetura atual

- `LlamaChatViewModel` instancia `JniLlamaEngineAdapter` como engine de produção.
- `JniLlamaEngineAdapter` implementa `LocalInferenceEngine` e controla o ciclo de vida do handle nativo, o streaming, o cancelamento e o telemetry.
- `app/src/main/cpp/CMakeLists.txt` busca `llama.cpp` na tag `v1.0.0` e compila a ponte `llama_jni.cpp` para `arm64-v8a`.
- O modelo é aberto diretamente de `filesDir/models/`, pasta gerenciada por `LocalModelStorageManager`.
- O template de conversa é o template Jinja embutido no GGUF. A engine não escolhe um template pelo nome do arquivo.
- O parser incremental do `common_chat_session` separa conteúdo e raciocínio quando o formato do modelo disponibiliza esses campos.

## Fluxo do contexto

1. O slider do chat dispara `UpdateContextLength`; o slider nas configurações usa a mesma configuração.
2. Se o modelo estiver carregado, a interface mostra `ConfigReloadBanner` enquanto houver alterações pendentes.
3. Ao tocar em **Recarregar**, o adaptador lê `llama_model_n_ctx_train()` para obter o contexto de treinamento declarado no modelo.
4. O estado de `loadedModel.maxContextLength` e a configuração aplicada são limitados por esse valor.
5. A cada nova inferência, o `n_ctx`, `n_batch` e `n_ubatch` são passados para `llama_context_params`.

O limite nativo é uma propriedade do GGUF; não equivale a uma garantia de que o telefone tenha RAM suficiente para alocar a janela solicitada.

## Modelos e armazenamento

- Downloads e importações usam arquivos `.part` temporários; apenas um arquivo com cabeçalho `GGUF` válido é movido para seu destino final.
- O arquivo final permanece em `filesDir/models/` e o JNI rejeita caminhos que não pertençam a essa pasta privada.
- A troca de modelo encerra uma geração ativa, libera o handle anterior e só então carrega o novo arquivo.
- A biblioteca dinâmica CPU é descoberta em `ApplicationInfo.nativeLibraryDir` para permitir o dispatch de variantes compatíveis com o processador.

## Configuração incluída

- CPU `arm64-v8a`; variantes de CPU selecionadas em runtime.
- `mmap`/`mlock`, cache K/V F16/Q8_0/Q4_0, contexto, lote, micro-lote, threads e sampler (repeat penalty, top-k, top-p, temperatura).
- Flash Attention configurado em `AUTO` para o llama.cpp habilitar apenas quando houver um caminho compatível.
- `releaseLocal` e `.github/workflows/android.yml` para testar e gerar um APK de instalação interna.

## Limitações conhecidas

- Não há offload de GPU nesta build.
- Não há entrada multimodal (`mtmd`/`mmproj`); por isso anexos de imagem não são aceitos.
- PDFs mostram nome e número de páginas, mas não têm extração textual. TXT/código/JSON/XML enviam uma prévia de até 12.000 caracteres.
- O CI compila e testa o projeto, mas a validação final de desempenho/compatibilidade exige aparelho físico ARM64 e arquivos GGUF reais.

## Compilação

Requisitos: JDK 21, Android SDK Platform 36 (minor API 1), Build Tools 36.0.0, NDK 27.2.12479018, CMake 3.22.1 e Gradle 9.3.1.

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
gradle :app:assembleReleaseLocal
```

O CMake clona `https://github.com/ggml-org/llama.cpp` na tag `v1.0.0` durante a configuração; é necessária conectividade de rede na primeira compilação.
