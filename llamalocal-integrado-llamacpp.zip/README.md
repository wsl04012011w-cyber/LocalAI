# Ayr off — IA local para Android

Aplicativo Android com interface em Jetpack Compose e inferência GGUF local por meio de `llama.cpp` JNI. A interface original do projeto foi mantida; a engine de demonstração foi substituída por uma implementação nativa.

## O que está integrado

- Inferência real em modelos GGUF, sem chamada a Gemini ou outro serviço de geração remoto.
- Template de conversa Jinja lido dos metadados do próprio GGUF (`tokenizer.chat_template`) e processado pelo módulo `common`/minja do `llama.cpp`.
- Resposta em streaming, cancelamento de geração e separação dos trechos de raciocínio para a caixa `<think>` da interface quando o template/modelo os fornece.
- Importação e download de GGUF para o diretório privado do aplicativo: `filesDir/models/`. O adaptador JNI usa o arquivo no próprio diretório, sem criar uma segunda cópia.
- Validação do cabeçalho GGUF antes de finalizar uma importação ou download.
- Slider rápido de contexto no chat e slider de contexto nas configurações. O máximo é atualizado com `llama_model_n_ctx_train()` após carregar cada modelo. Mudanças ficam pendentes até tocar em **Recarregar**.
- Cache K/V quantizado (F16, Q8_0 e Q4_0), mmap/mlock, tamanho de lote, threads e parâmetros de amostragem.
- Log nativo e workflow de CI para testes e geração do APK `releaseLocal`.

## Limitações desta build

- **Arquitetura:** somente Android `arm64-v8a` (64 bits ARM).
- **Backend:** CPU. Esta configuração não compila um backend de GPU/offload; por isso o controle de camadas GPU não aparece como recurso disponível.
- **Imagens:** entrada multimodal ainda não está integrada (`mtmd`/projetor multimodal); o seletor de imagens fica desativado.
- **PDF:** o anexo informa o nome e a quantidade de páginas, mas ainda não extrai o texto das páginas. Arquivos TXT, código, JSON e XML enviam uma prévia de até 12.000 caracteres.
- **Contexto e memória:** o slider respeita o limite de treinamento declarado pelo GGUF, não a RAM disponível do telefone. Contextos maiores consomem mais memória e podem fazer o Android encerrar o app; aumente o valor gradualmente.
- **Templates:** modelos sem um `tokenizer.chat_template` utilizável podem não iniciar uma conversa formatada. O adaptador não substitui o template do arquivo por um template adivinhado a partir do nome.

## Requisitos de build

Abra o diretório do projeto no Android Studio e permita a sincronização do Gradle. A configuração utilizada pelo workflow é:

- JDK 21
- Android Gradle Plugin 9.1.1 / Gradle 9.3.1
- Android SDK Platform 36 (minor API 1) e Build Tools 36.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1

O CMake busca o `llama.cpp` pela tag `v1.0.0` via `FetchContent`; a primeira compilação precisa de acesso à internet para obter o código-fonte e compilar as bibliotecas nativas.

## Compilar e testar

No Android Studio, selecione um dispositivo/emulador ARM64 e execute as tarefas Gradle:

```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
gradle :app:assembleReleaseLocal
```

O workflow `.github/workflows/android.yml` executa os testes unitários e `assembleReleaseLocal` em GitHub Actions e publica o APK como artefato do job. `releaseLocal` usa a chave de debug gerada pelo Android Gradle Plugin para instalação/teste interno; não é uma assinatura de publicação na Play Store. Para publicar, configure as variáveis `KEYSTORE_PATH`, `STORE_PASSWORD` e `KEY_PASSWORD` com sua chave de upload e construa a variante `release`.

## Utilizar modelos

1. Instale o aplicativo em um aparelho Android 64-bit ARM.
2. Na tela **Modelos**, baixe um modelo do catálogo ou importe um arquivo `.gguf` pelo seletor de documentos.
3. Toque em **Carregar**. O app valida o cabeçalho e carrega o arquivo da pasta privada.
4. No chat, toque no botão de contexto para ajustar rapidamente `n_ctx`; confirme a alteração em **Recarregar** para criar a próxima sessão de inferência com o novo tamanho.
5. Comece com uma janela de contexto menor. Nem todo aparelho consegue manter modelos grandes ou janelas longas na memória, mesmo quando o GGUF declara suporte.

## Privacidade

A geração ocorre no próprio dispositivo. O app acessa a internet apenas para baixar modelos e suas dependências de build; não precisa de `GEMINI_API_KEY`. Arquivos importados/baixados ficam no armazenamento privado do app e são removidos ao excluir o modelo ou desinstalar o aplicativo.
