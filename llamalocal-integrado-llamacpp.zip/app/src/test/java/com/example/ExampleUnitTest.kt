package com.example

import com.example.data.GgufRepository
import com.example.domain.model.ChatAttachment
import com.example.domain.model.ChatMessage
import com.example.domain.model.ChatTemplateFormat
import com.example.domain.model.EngineLimits
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.GgufQuantization
import com.example.domain.model.InferenceConfig
import com.example.domain.model.KvCacheQuant
import com.example.domain.model.MessageRole
import com.example.domain.model.ThinkingLevel
import com.example.domain.model.ThinkingSupportMode
import com.example.engine.EngineLifecycleState
import com.example.engine.FinishReason
import com.example.engine.InferenceStreamEvent
import com.example.engine.PromptFormatter
import com.example.engine.StubLlamaEngineAdapter
import com.example.engine.ThinkingParser
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun promptFormatter_formatsJinjaTemplatesAndThinkingLevels() {
        val messages = listOf(
            ChatMessage(
                role = MessageRole.USER,
                content = "Analise este arquivo",
                attachments = listOf(
                    ChatAttachment(
                        name = "notas.txt",
                        mimeType = "text/plain",
                        uriString = "content://test/1",
                        isImage = false,
                        extractedText = "conteudo"
                    )
                )
            )
        )
        val llama3Model = GgufModelSpec(
            id = "llama3",
            name = "Llama 3.2",
            architecture = "Llama",
            parameterLabel = "3B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "llama3.gguf",
            fileSizeMb = 2000,
            estimatedRamMb = 2400,
            maxContextLength = 131_072,
            defaultTemplate = ChatTemplateFormat.LLAMA3,
            description = "test"
        )
        val qwen3Model = llama3Model.copy(
            id = "qwen3",
            defaultTemplate = ChatTemplateFormat.QWEN3,
            thinkingSupport = ThinkingSupportMode.LEVELS
        )

        val llamaPrompt = PromptFormatter.formatPrompt(
            messages = messages,
            config = InferenceConfig(systemPrompt = "Sys"),
            model = llama3Model
        )
        assertTrue(llamaPrompt.contains("<|begin_of_text|>"))
        assertTrue(llamaPrompt.contains("[Arquivo: notas.txt]"))

        val qwenHigh = PromptFormatter.formatPrompt(
            messages = messages,
            config = InferenceConfig(systemPrompt = "Sys", thinkingLevel = ThinkingLevel.XHIGH),
            model = qwen3Model
        )
        assertTrue(qwenHigh.contains("Reasoning: xhigh"))
        assertFalse(qwenHigh.contains("/no_think"))

        val qwenOff = PromptFormatter.formatPrompt(
            messages = messages,
            config = InferenceConfig(systemPrompt = "Sys", thinkingLevel = ThinkingLevel.OFF),
            model = qwen3Model
        )
        assertTrue(qwenOff.contains("/no_think"))
        assertTrue(qwenOff.endsWith("<think>\n\n</think>\n\n"))
    }

    @Test
    fun thinkingParser_extractsStreamingAndCompletedThinkBlocks() {
        val activeStream = ThinkingParser.parse("<think>Analisando passos")
        assertTrue(activeStream.isThinkingActive)
        assertEquals("Analisando passos", activeStream.thinkingText)
        assertEquals("", activeStream.answerText)

        val finished = ThinkingParser.parse("<think>Passo 1\nPasso 2</think>\n\nResposta final.")
        assertFalse(finished.isThinkingActive)
        assertEquals("Passo 1\nPasso 2", finished.thinkingText)
        assertEquals("Resposta final.", finished.answerText)
    }

    @Test
    fun kvCacheEstimation_scalesWithQuantization() {
        val f16 = InferenceConfig(contextLength = 4096, kvCacheQuant = KvCacheQuant.F16)
        val q8 = InferenceConfig(contextLength = 4096, kvCacheQuant = KvCacheQuant.Q8_0)
        val q4 = InferenceConfig(contextLength = 4096, kvCacheQuant = KvCacheQuant.Q4_0)

        assertTrue(f16.estimateKvCacheMb(null) > q8.estimateKvCacheMb(null))
        assertTrue(q8.estimateKvCacheMb(null) > q4.estimateKvCacheMb(null))
    }

    @Test
    fun repositoryModels_includeThinkingLevelsAndValidHuggingFaceUrls() {
        val repo = GgufRepository(defaultThreads = 4)
        val models = repo.models.value
        assertTrue(models.any { it.thinkingSupport == ThinkingSupportMode.LEVELS })
        assertTrue(models.any { it.thinkingSupport == ThinkingSupportMode.BINARY })
        assertTrue(models.none { it.supportsVision })
        models.forEach { model ->
            val url = model.downloadUrl.orEmpty()
            assertTrue(url.startsWith("https://huggingface.co/"))
            assertTrue(url.contains(".gguf"))
        }
        assertEquals(131_072, EngineLimits.DEFAULT_MAX_MODEL_CONTEXT)
    }

    @Test
    fun previewEngine_respectsThinkingLevelToggleAndStreams() = runTest {
        val engine = StubLlamaEngineAdapter()
        assertEquals(EngineLifecycleState.UNLOADED, engine.engineState.value)

        val spec = GgufModelSpec(
            id = "test_r1",
            name = "DeepSeek-R1 Test",
            architecture = "DeepSeek-R1",
            parameterLabel = "1.5B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "r1-test.gguf",
            fileSizeMb = 1100,
            estimatedRamMb = 1400,
            maxContextLength = 131_072,
            defaultTemplate = ChatTemplateFormat.DEEPSEEK_R1,
            thinkingSupport = ThinkingSupportMode.BINARY,
            isDownloaded = true,
            description = "Thinking test slot"
        )
        val configOn = InferenceConfig(
            maxTokens = 24,
            threads = 4,
            contextLength = 32768,
            thinkingLevel = ThinkingLevel.HIGH
        )

        val loadRes = engine.loadModel(spec, configOn)
        assertTrue(loadRes.isSuccess)
        assertEquals(EngineLifecycleState.READY, engine.engineState.value)

        val eventsOn = engine.streamCompletion(
            messages = listOf(ChatMessage(role = MessageRole.USER, content = "Teste")),
            config = configOn
        ).toList()

        assertTrue(eventsOn.first() is InferenceStreamEvent.Started)
        val textOn = eventsOn.filterIsInstance<InferenceStreamEvent.Token>().joinToString("") { it.text }
        assertTrue(textOn.contains("<think>"))
        val completedOn = eventsOn.last() as InferenceStreamEvent.Completed
        assertEquals(FinishReason.MAX_TOKENS, completedOn.finishReason)

        val eventsOff = engine.streamCompletion(
            messages = listOf(ChatMessage(role = MessageRole.USER, content = "Teste")),
            config = configOn.copy(thinkingLevel = ThinkingLevel.OFF)
        ).toList()
        val textOff = eventsOff.filterIsInstance<InferenceStreamEvent.Token>().joinToString("") { it.text }
        assertFalse(textOff.contains("<think>"))
    }
}
