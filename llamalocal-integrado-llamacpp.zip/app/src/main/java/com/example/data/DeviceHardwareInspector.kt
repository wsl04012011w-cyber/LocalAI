package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.domain.model.ChatAttachment
import com.example.domain.model.ChatTemplateFormat
import com.example.domain.model.DeviceMemoryInfo
import com.example.domain.model.EngineLimits
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.GgufQuantization
import com.example.domain.model.ModelOrigin
import com.example.domain.model.ThinkingSupportMode
import java.io.File

class DeviceHardwareInspector(private val context: Context) {

    private companion object {
        const val MAX_ATTACHMENT_TEXT_CHARS = 12_000
    }

    fun inspectMemoryAndCpu(): DeviceMemoryInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memInfo)

        val totalMb = (memInfo.totalMem / (1024L * 1024L)).toInt().coerceAtLeast(1024)
        val availMb = (memInfo.availMem / (1024L * 1024L)).toInt().coerceAtLeast(256)
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
        val primaryAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val isArm64 = Build.SUPPORTED_ABIS.any { it.contains("arm64", ignoreCase = true) }

        return DeviceMemoryInfo(
            totalRamMb = totalMb,
            availableRamMb = availMb,
            cpuCores = cores,
            primaryAbi = primaryAbi,
            isArm64 = isArm64
        )
    }

    fun inspectLocalModelFile(file: File): GgufModelSpec {
        val displayName = file.name
        val sizeMb = (file.length() / (1024L * 1024L)).toInt().coerceAtLeast(1)
        val cleanName = displayName.removeSuffix(".gguf").replace('-', ' ').replace('_', ' ')

        return GgufModelSpec(
            id = "local_${displayName.hashCode()}",
            name = cleanName.take(36),
            architecture = inferArchitecture(displayName),
            parameterLabel = inferParamSize(sizeMb),
            quantization = detectQuantFromFilename(displayName),
            fileName = displayName,
            fileSizeMb = sizeMb,
            estimatedRamMb = (sizeMb * 1.18f).toInt(),
            maxContextLength = EngineLimits.DEFAULT_MAX_MODEL_CONTEXT,
            defaultTemplate = detectTemplateFromFilename(displayName),
            thinkingSupport = detectThinkingMode(displayName),
            supportsVision = detectVisionSupport(displayName),
            isDownloaded = true,
            localFilePath = file.absolutePath,
            origin = ModelOrigin.DEVICE_STORAGE,
            description = "Modelo armazenado na pasta privada do app."
        )
    }

    fun inspectAttachmentUri(uri: Uri, forceImage: Boolean): ChatAttachment? {
        var displayName = if (forceImage) "imagem.jpg" else "documento.txt"
        var sizeBytes = 0L

        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx != -1) {
                    displayName = cursor.getString(nameIdx) ?: displayName
                }
                if (sizeIdx != -1) {
                    sizeBytes = cursor.getLong(sizeIdx)
                }
            }
        }

        val mimeType = context.contentResolver.getType(uri)
            ?: if (forceImage) "image/*" else "text/plain"
        val isImage = forceImage || mimeType.startsWith("image/")

        val extractedText = if (isImage) {
            null
        } else if (mimeType == "application/pdf" || displayName.endsWith(".pdf", ignoreCase = true)) {
            extractPdfInfo(uri, displayName)
        } else {
            readTextPreview(uri)
        }

        return ChatAttachment(
            name = displayName,
            mimeType = mimeType,
            uriString = uri.toString(),
            isImage = isImage,
            extractedText = extractedText,
            sizeBytes = sizeBytes
        )
    }

    private fun readTextPreview(uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                val content = StringBuilder(MAX_ATTACHMENT_TEXT_CHARS)
                val buffer = CharArray(2_048)
                while (content.length < MAX_ATTACHMENT_TEXT_CHARS) {
                    val remaining = MAX_ATTACHMENT_TEXT_CHARS - content.length
                    val read = reader.read(buffer, 0, minOf(buffer.size, remaining))
                    if (read < 0) break
                    if (read == 0) continue
                    content.append(buffer, 0, read)
                }
                val truncated = reader.read() != -1
                if (truncated) {
                    val marker = "\n\n[Prévia truncada após $MAX_ATTACHMENT_TEXT_CHARS caracteres.]"
                    content.setLength((MAX_ATTACHMENT_TEXT_CHARS - marker.length).coerceAtLeast(0))
                    content.append(marker)
                }
                content.toString()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun extractPdfInfo(uri: Uri, name: String): String {
        return try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            val pages = pfd?.use { fd ->
                PdfRenderer(fd).use { renderer -> renderer.pageCount }
            } ?: 0
            "Documento PDF \"$name\" ($pages páginas)."
        } catch (_: Throwable) {
            "Documento PDF \"$name\"."
        }
    }

    private fun detectQuantFromFilename(name: String): GgufQuantization {
        val upper = name.uppercase()
        return GgufQuantization.entries.firstOrNull { upper.contains(it.name) }
            ?: GgufQuantization.Q4_K_M
    }

    private fun detectTemplateFromFilename(name: String): ChatTemplateFormat {
        val lower = name.lowercase()
        return when {
            lower.contains("deepseek") || lower.contains("r1") -> ChatTemplateFormat.DEEPSEEK_R1
            lower.contains("qwen3") -> ChatTemplateFormat.QWEN3
            lower.contains("qwen") -> ChatTemplateFormat.CHATML
            lower.contains("gemma") -> ChatTemplateFormat.GEMMA
            lower.contains("phi") -> ChatTemplateFormat.PHI3
            else -> ChatTemplateFormat.LLAMA3
        }
    }

    private fun detectThinkingMode(name: String): ThinkingSupportMode {
        val lower = name.lowercase()
        return when {
            lower.contains("qwen3") || lower.contains("gpt-oss") -> ThinkingSupportMode.LEVELS
            lower.contains("r1") || lower.contains("think") || lower.contains("qwq") -> ThinkingSupportMode.BINARY
            else -> ThinkingSupportMode.NONE
        }
    }

    // The current JNI target links llama.cpp text inference only. Do not advertise
    // image input until mtmd/mmproj is part of the native build.
    private fun detectVisionSupport(name: String): Boolean = false

    private fun inferArchitecture(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.contains("deepseek") -> "DeepSeek-R1"
            lower.contains("qwen3") -> "Qwen3"
            lower.contains("qwen") -> "Qwen2.5"
            lower.contains("smolvlm") -> "SmolVLM"
            lower.contains("gemma") -> "Gemma2"
            lower.contains("phi") -> "Phi-3.5"
            lower.contains("mistral") -> "Mistral"
            else -> "Llama"
        }
    }

    private fun inferParamSize(sizeMb: Int): String = when {
        sizeMb < 750 -> "~0.5B"
        sizeMb < 1150 -> "~1.5B"
        sizeMb < 2200 -> "~3B"
        sizeMb < 4200 -> "~4B–7B"
        else -> "~8B+"
    }
}
