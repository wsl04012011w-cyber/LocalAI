package com.example.data

import com.example.domain.model.ChatAttachment
import com.example.domain.model.ChatMessage
import com.example.domain.model.ChatTemplateFormat
import com.example.domain.model.ConversationSession
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.GgufQuantization
import com.example.domain.model.InferenceConfig
import com.example.domain.model.ModelOrigin
import com.example.domain.model.ThinkingSupportMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.util.UUID

class GgufRepository(
    defaultThreads: Int,
    private val localPathResolver: (String) -> String? = { null },
    private val customFileScanner: (Set<String>) -> List<File> = { emptyList() },
    private val customFileInspector: ((File) -> GgufModelSpec)? = null
) {

    private val catalogModels = defaultCatalogModels()
    private val catalogFileNames = catalogModels.map { it.fileName }.toSet()

    private val _models = MutableStateFlow(buildSyncedModelList())
    val models: StateFlow<List<GgufModelSpec>> = _models.asStateFlow()

    private val initialSession = ConversationSession(
        id = UUID.randomUUID().toString(),
        title = "Nova Conversa"
    )

    private val _sessions = MutableStateFlow(listOf(initialSession))
    val sessions: StateFlow<List<ConversationSession>> = _sessions.asStateFlow()

    private val _activeSessionId = MutableStateFlow(initialSession.id)
    val activeSessionId: StateFlow<String> = _activeSessionId.asStateFlow()

    private val _config = MutableStateFlow(
        InferenceConfig(
            threads = defaultThreads.coerceIn(1, 16)
        )
    )
    val config: StateFlow<InferenceConfig> = _config.asStateFlow()

    fun syncStoredModels() {
        _models.value = buildSyncedModelList()
    }

    private fun buildSyncedModelList(): List<GgufModelSpec> {
        val customModels = if (customFileInspector != null) {
            customFileScanner(catalogFileNames).map { file -> customFileInspector.invoke(file) }
        } else {
            emptyList()
        }
        val syncedCatalog = catalogModels.map { spec ->
            val path = localPathResolver(spec.fileName)
            spec.copy(
                isDownloaded = path != null,
                localFilePath = path
            )
        }
        return customModels + syncedCatalog
    }

    fun updateConfig(transform: (InferenceConfig) -> InferenceConfig) {
        _config.update(transform)
    }

    fun createNewSession(modelId: String?): ConversationSession {
        val session = ConversationSession(
            id = UUID.randomUUID().toString(),
            title = "Nova Conversa",
            modelId = modelId
        )
        _sessions.update { listOf(session) + it }
        _activeSessionId.value = session.id
        return session
    }

    fun selectSession(sessionId: String) {
        if (_sessions.value.any { it.id == sessionId }) {
            _activeSessionId.value = sessionId
        }
    }

    fun deleteSession(sessionId: String) {
        _sessions.update { current ->
            val remaining = current.filterNot { it.id == sessionId }
            if (remaining.isEmpty()) {
                val fallback = ConversationSession(title = "Nova Conversa")
                _activeSessionId.value = fallback.id
                listOf(fallback)
            } else {
                if (_activeSessionId.value == sessionId) {
                    _activeSessionId.value = remaining.first().id
                }
                remaining
            }
        }
    }

    fun updateSessionMessages(
        sessionId: String,
        autoTitleFromFirstPrompt: String? = null,
        attachmentsForTitle: List<ChatAttachment> = emptyList(),
        transform: (List<ChatMessage>) -> List<ChatMessage>
    ) {
        _sessions.update { list ->
            list.map { session ->
                if (session.id != sessionId) return@map session
                val updatedMessages = transform(session.messages)
                val updatedTitle = if (
                    autoTitleFromFirstPrompt != null &&
                    session.title == "Nova Conversa"
                ) {
                    val candidate = autoTitleFromFirstPrompt.trim().ifBlank {
                        attachmentsForTitle.firstOrNull()?.name.orEmpty()
                    }
                    candidate.take(34).ifBlank { session.title }
                } else {
                    session.title
                }
                session.copy(
                    title = updatedTitle,
                    updatedAtMs = System.currentTimeMillis(),
                    messages = updatedMessages
                )
            }
        }
    }

    private fun defaultCatalogModels(): List<GgufModelSpec> = listOf(
        GgufModelSpec(
            id = "slot_qwen3_1_7b",
            name = "Qwen3 1.7B",
            architecture = "Qwen3",
            parameterLabel = "1.7B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "Qwen3-1.7B-Q4_K_M.gguf",
            fileSizeMb = 1110,
            estimatedRamMb = 1480,
            maxContextLength = 40960,
            defaultTemplate = ChatTemplateFormat.QWEN3,
            thinkingSupport = ThinkingSupportMode.LEVELS,
            supportsVision = false,
            downloadUrl = "https://huggingface.co/unsloth/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf?download=true",
            repositoryUrl = "https://huggingface.co/unsloth/Qwen3-1.7B-GGUF",
            description = "Suporta níveis de raciocínio (Off, Low, Médio, Alto, XHigh)."
        ),
        GgufModelSpec(
            id = "slot_deepseek_r1_1_5b",
            name = "DeepSeek-R1 Distill Qwen 1.5B",
            architecture = "DeepSeek-R1",
            parameterLabel = "1.5B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf",
            fileSizeMb = 1120,
            estimatedRamMb = 1420,
            maxContextLength = 131072,
            defaultTemplate = ChatTemplateFormat.DEEPSEEK_R1,
            thinkingSupport = ThinkingSupportMode.BINARY,
            supportsVision = false,
            downloadUrl = "https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF/resolve/main/DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf?download=true",
            repositoryUrl = "https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF",
            description = "Raciocínio estruturado com alternância Think."
        ),
        GgufModelSpec(
            id = "slot_smolvlm_500m",
            name = "SmolVLM 500M Instruct",
            architecture = "SmolVLM",
            parameterLabel = "0.5B",
            quantization = GgufQuantization.Q8_0,
            fileName = "SmolVLM-500M-Instruct-Q8_0.gguf",
            fileSizeMb = 437,
            estimatedRamMb = 720,
            maxContextLength = 16384,
            defaultTemplate = ChatTemplateFormat.CHATML,
            thinkingSupport = ThinkingSupportMode.NONE,
            supportsVision = false,
            downloadUrl = "https://huggingface.co/ggml-org/SmolVLM-500M-Instruct-GGUF/resolve/main/SmolVLM-500M-Instruct-Q8_0.gguf?download=true",
            repositoryUrl = "https://huggingface.co/ggml-org/SmolVLM-500M-Instruct-GGUF",
            description = "Modelo compacto. Esta build processa texto; suporte a imagens requer o módulo mtmd e o projetor multimodal."
        ),
        GgufModelSpec(
            id = "slot_qwen25_1_5b",
            name = "Qwen 2.5 Instruct",
            architecture = "Qwen2.5",
            parameterLabel = "1.5B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
            fileSizeMb = 986,
            estimatedRamMb = 1280,
            maxContextLength = 32768,
            defaultTemplate = ChatTemplateFormat.CHATML,
            thinkingSupport = ThinkingSupportMode.NONE,
            supportsVision = false,
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf?download=true",
            repositoryUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF",
            description = "Leve e veloz para respostas diretas."
        ),
        GgufModelSpec(
            id = "slot_llama32_3b",
            name = "Llama 3.2 Instruct",
            architecture = "Llama",
            parameterLabel = "3B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
            fileSizeMb = 2019,
            estimatedRamMb = 2480,
            maxContextLength = 131072,
            defaultTemplate = ChatTemplateFormat.LLAMA3,
            thinkingSupport = ThinkingSupportMode.NONE,
            supportsVision = false,
            downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf?download=true",
            repositoryUrl = "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF",
            description = "Uso geral com janela de 128K."
        ),
        GgufModelSpec(
            id = "slot_phi35_mini",
            name = "Phi-3.5 Mini Instruct",
            architecture = "Phi-3.5",
            parameterLabel = "3.8B",
            quantization = GgufQuantization.Q4_K_M,
            fileName = "Phi-3.5-mini-instruct-Q4_K_M.gguf",
            fileSizeMb = 2390,
            estimatedRamMb = 2900,
            maxContextLength = 131072,
            defaultTemplate = ChatTemplateFormat.PHI3,
            thinkingSupport = ThinkingSupportMode.NONE,
            supportsVision = false,
            downloadUrl = "https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF/resolve/main/Phi-3.5-mini-instruct-Q4_K_M.gguf?download=true",
            repositoryUrl = "https://huggingface.co/bartowski/Phi-3.5-mini-instruct-GGUF",
            description = "Focado em lógica e raciocínio estruturado."
        )
    )
}
