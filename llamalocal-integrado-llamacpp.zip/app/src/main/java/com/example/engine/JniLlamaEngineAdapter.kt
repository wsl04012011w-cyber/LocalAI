package com.example.engine

import android.content.Context
import com.example.data.AppDiagnosticsLogger
import com.example.domain.model.ChatMessage
import com.example.domain.model.EngineLimits
import com.example.domain.model.EngineTelemetry
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.InferenceConfig
import com.example.domain.model.KvCacheQuant
import com.example.domain.model.MessageRole
import com.example.domain.model.ThinkingLevel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Real GGUF inference through llama.cpp JNI.
 * The UI's LocalModelStorageManager owns the files in filesDir/models; this
 * adapter reads those files in place and never creates a second model copy.
 */
class JniLlamaEngineAdapter(
    context: Context
) : LocalInferenceEngine, Closeable {

    private val appContext = context.applicationContext
    private val modelsDirectory = File(appContext.filesDir, "models")
    private val nativeDispatcher = Dispatchers.IO.limitedParallelism(1)
    private val operationMutex = Mutex()
    private val cleanupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var nativeHandle: Long = 0L

    @Volatile
    private var activeGenerationId: Long = 0L

    @Volatile
    private var loadedConfig: InferenceConfig? = null

    private val _engineState = MutableStateFlow(EngineLifecycleState.UNLOADED)
    override val engineState: StateFlow<EngineLifecycleState> = _engineState.asStateFlow()

    private val _loadedModel = MutableStateFlow<GgufModelSpec?>(null)
    override val loadedModel: StateFlow<GgufModelSpec?> = _loadedModel.asStateFlow()

    private val _telemetry = MutableStateFlow(EngineTelemetry())
    override val telemetry: StateFlow<EngineTelemetry> = _telemetry.asStateFlow()

    override val isNativeBridgeLinked: Boolean
        get() = NativeLibrary.ensureLoaded()

    init {
        AppDiagnosticsLogger.initialize(appContext)
        modelsDirectory.mkdirs()
    }

    override suspend fun loadModel(
        model: GgufModelSpec,
        config: InferenceConfig
    ): Result<Unit> {
        // Request cancellation before waiting for the mutex held by nativeGenerate().
        requestActiveGenerationStop()
        return operationMutex.withLock {
            withContext(nativeDispatcher) {
                _engineState.value = EngineLifecycleState.LOADING_MODEL
                releaseModelInternal()

                if (!NativeLibrary.ensureLoaded()) {
                    val cause = NativeLibrary.failure
                    val message = "A biblioteca nativa llama.cpp não foi carregada. " +
                        (cause?.message ?: "Verifique a ABI arm64-v8a e a compilação NDK.")
                    _engineState.value = EngineLifecycleState.ERROR
                    AppDiagnosticsLogger.error("NATIVE", message, cause)
                    return@withContext Result.failure(IllegalStateException(message, cause))
                }

                if (config.gpuLayers > 0 && !runCatching { nativeSupportsGpuOffload() }.getOrDefault(false)) {
                    _engineState.value = EngineLifecycleState.ERROR
                    return@withContext Result.failure(
                        IllegalStateException(
                            "Esta versão foi compilada com backend CPU. Defina Camadas na GPU como 0."
                        )
                    )
                }

                var pendingNativeHandle = 0L
                try {
                    val modelFile = resolvePrivateModelFile(model)
                    requireValidGguf(modelFile)

                    val safeConfig = config.copy(
                        // The final upper bound comes from llama_model_n_ctx_train after load.
                        // Do not clamp custom GGUFs using a filename-based context guess.
                        contextLength = config.contextLength.coerceAtLeast(EngineLimits.MIN_CONTEXT),
                        threads = config.threads.coerceIn(EngineLimits.MIN_THREADS, EngineLimits.MAX_THREADS),
                        batchSize = config.batchSize.coerceIn(EngineLimits.MIN_BATCH, EngineLimits.MAX_BATCH),
                        gpuLayers = config.gpuLayers.coerceIn(EngineLimits.MIN_GPU_LAYERS, EngineLimits.MAX_GPU_LAYERS)
                    )

                    AppDiagnosticsLogger.info(
                        "MODEL",
                        "Carregando ${model.fileName}; path=${modelFile.absolutePath}; bytes=${modelFile.length()}; " +
                            "n_ctx=${safeConfig.contextLength}; n_batch=${safeConfig.batchSize}; " +
                            "threads=${safeConfig.threads}; mmap=${safeConfig.useMmap}; mlock=${safeConfig.useMlock}"
                    )

                    val handle = nativeLoadModel(
                        modelFile.absolutePath,
                        safeConfig.gpuLayers,
                        safeConfig.useMmap,
                        safeConfig.useMlock,
                        AppDiagnosticsLogger.logFilePath(appContext),
                        appContext.applicationInfo.nativeLibraryDir
                    )
                    check(handle != 0L) { "llama.cpp não retornou um handle válido para o GGUF." }
                    pendingNativeHandle = handle
                    // JNI model loading is a blocking native call. Honour cancellation as soon
                    // as it returns and do not leak a model if the screen was closed meanwhile.
                    currentCoroutineContext().ensureActive()

                    val nativeContextLimit = runCatching { nativeModelContextLength(handle) }
                        .getOrDefault(0)
                        .takeIf { it >= EngineLimits.MIN_CONTEXT }
                        ?: model.maxContextLength
                    val effectiveMaxContext = nativeContextLimit.coerceAtLeast(EngineLimits.MIN_CONTEXT)
                    val applied = safeConfig.copy(
                        contextLength = safeConfig.contextLength.coerceAtMost(effectiveMaxContext),
                        maxTokens = safeConfig.maxTokens.coerceAtMost(effectiveMaxContext)
                    )

                    nativeHandle = handle
                    pendingNativeHandle = 0L
                    loadedConfig = applied
                    val loadedSpec = model.copy(
                        isDownloaded = true,
                        localFilePath = modelFile.absolutePath,
                        maxContextLength = effectiveMaxContext
                    )
                    _loadedModel.value = loadedSpec
                    val kvCacheMb = applied.estimateKvCacheMb(loadedSpec)
                    _telemetry.value = EngineTelemetry(
                        estimatedKvCacheMb = kvCacheMb,
                        estimatedTotalFootprintMb = loadedSpec.estimatedRamMb + kvCacheMb
                    )
                    _engineState.value = EngineLifecycleState.READY
                    AppDiagnosticsLogger.info("MODEL", "Modelo READY: ${model.fileName}; handle=$handle")
                    Result.success(Unit)
                } catch (cancelled: CancellationException) {
                    if (pendingNativeHandle != 0L) {
                        runCatching { nativeFreeModel(pendingNativeHandle) }
                        pendingNativeHandle = 0L
                    }
                    _engineState.value = EngineLifecycleState.ERROR
                    AppDiagnosticsLogger.warn("MODEL", "Carregamento cancelado: ${model.fileName}")
                    throw cancelled
                } catch (failure: Throwable) {
                    if (pendingNativeHandle != 0L) {
                        runCatching { nativeFreeModel(pendingNativeHandle) }
                        pendingNativeHandle = 0L
                    }
                    _engineState.value = EngineLifecycleState.ERROR
                    AppDiagnosticsLogger.error("MODEL", "Falha ao carregar ${model.fileName}", failure)
                    Result.failure(failure)
                }
            }
        }
    }

    override suspend fun unloadModel() {
        requestActiveGenerationStop()
        operationMutex.withLock {
            withContext(nativeDispatcher) {
                releaseModelInternal()
                _telemetry.value = EngineTelemetry()
                _engineState.value = EngineLifecycleState.UNLOADED
            }
        }
    }

    override fun streamCompletion(
        messages: List<ChatMessage>,
        config: InferenceConfig
    ): Flow<InferenceStreamEvent> = channelFlow {
        val handle = nativeHandle
        val model = _loadedModel.value
        val baseConfig = loadedConfig
        if (handle == 0L || model == null || baseConfig == null) {
            send(
                InferenceStreamEvent.Error(
                    "Nenhum modelo GGUF está carregado. Abra Modelos e carregue um arquivo privado.",
                    recoverable = true
                )
            )
            return@channelFlow
        }

        val imageAttachments = messages.asSequence()
            .flatMap { it.attachments.asSequence() }
            .filter { it.isImage }
            .toList()
        if (imageAttachments.isNotEmpty()) {
            send(
                InferenceStreamEvent.Error(
                    "Esta compilação ainda não inclui o módulo multimodal mtmd. Remova as imagens ou use um modelo de texto.",
                    recoverable = true
                )
            )
            return@channelFlow
        }

        val generationId = NEXT_GENERATION_ID.getAndIncrement()
        activeGenerationId = generationId
        val producer = this
        val generationFinished = AtomicBoolean(false)

        // Sampling controls are reload-bound. Only ThinkingLevel is per-prompt.
        val effectiveConfig = baseConfig.copy(thinkingLevel = config.thinkingLevel)
        val (roles, contents) = prepareChatMessages(messages, effectiveConfig)

        AppDiagnosticsLogger.info(
            "INFERENCE",
            "Geração id=$generationId; model=${model.fileName}; messages=${messages.size}; " +
                "n_ctx=${effectiveConfig.contextLength}; n_batch=${effectiveConfig.batchSize}; " +
                "threads=${effectiveConfig.threads}; thinking=${effectiveConfig.thinkingLevel.effortValue}"
        )

        val generationJob = launch(nativeDispatcher) {
            var promptTokens = 0
            var thinkingOpened = false
            var thinkingClosed = false
            try {
                operationMutex.withLock {
                    if (nativeHandle != handle) {
                        producer.trySend(InferenceStreamEvent.Error("O modelo foi descarregado antes do início da geração."))
                        return@withLock
                    }

                    _engineState.value = EngineLifecycleState.GENERATING
                    nativeGenerate(
                        handle = handle,
                        generationId = generationId,
                        roles = roles,
                        contents = contents,
                        contextLength = effectiveConfig.contextLength,
                        batchSize = effectiveConfig.batchSize,
                        threads = effectiveConfig.threads,
                        kvCacheType = effectiveConfig.kvCacheQuant.toNativeType(),
                        maxTokens = effectiveConfig.maxTokens,
                        temperature = effectiveConfig.temperature,
                        topP = effectiveConfig.topP,
                        topK = effectiveConfig.topK,
                        repeatPenalty = effectiveConfig.repeatPenalty,
                        microBatchSize = minOf(effectiveConfig.batchSize, 512),
                        flashAttentionType = FLASH_ATTN_AUTO,
                        enableThinking = effectiveConfig.thinkingLevel != ThinkingLevel.OFF,
                        thinkingLevel = effectiveConfig.thinkingLevel.ordinal,
                        callbacks = object : NativeCallbacks {
                            override fun onStarted(tokenCount: Int, promptEvalMs: Long) {
                                promptTokens = tokenCount
                                _telemetry.value = _telemetry.value.copy(
                                    promptTokensUsed = tokenCount,
                                    generatedTokens = 0,
                                    tokensPerSecond = 0f,
                                    promptEvalMs = promptEvalMs
                                )
                                producer.trySend(
                                    InferenceStreamEvent.Started(
                                        promptTokens = tokenCount,
                                        promptEvalTimeMs = promptEvalMs
                                    )
                                )
                            }

                            override fun onThinking(text: String) {
                                if (text.isEmpty()) return
                                if (!thinkingOpened) {
                                    thinkingOpened = true
                                    producer.trySend(InferenceStreamEvent.Token("<think>", 0, 0f))
                                }
                                producer.trySend(InferenceStreamEvent.Token(text, 0, 0f))
                            }

                            override fun onToken(text: String, totalTokens: Int, tokensPerSecond: Float) {
                                if (text.isEmpty()) return
                                if (thinkingOpened && !thinkingClosed) {
                                    thinkingClosed = true
                                    producer.trySend(InferenceStreamEvent.Token("</think>\n\n", totalTokens, tokensPerSecond))
                                }
                                _telemetry.value = _telemetry.value.copy(
                                    promptTokensUsed = promptTokens,
                                    generatedTokens = totalTokens,
                                    tokensPerSecond = tokensPerSecond
                                )
                                producer.trySend(
                                    InferenceStreamEvent.Token(
                                        text = text,
                                        totalTokens = totalTokens,
                                        tokensPerSecond = tokensPerSecond
                                    )
                                )
                            }

                            override fun onCompleted(
                                finishReason: Int,
                                totalTokens: Int,
                                tokensPerSecond: Float,
                                durationMs: Long
                            ) {
                                if (thinkingOpened && !thinkingClosed) {
                                    thinkingClosed = true
                                    producer.trySend(InferenceStreamEvent.Token("</think>\n\n", totalTokens, tokensPerSecond))
                                }
                                _engineState.value = EngineLifecycleState.READY
                                producer.trySend(
                                    InferenceStreamEvent.Completed(
                                        finishReason = finishReason.toFinishReason(),
                                        totalTokens = totalTokens,
                                        tokensPerSecond = tokensPerSecond,
                                        durationMs = durationMs
                                    )
                                )
                            }

                            override fun onError(message: String) {
                                // A bad prompt/context must not strand a successfully loaded model in ERROR.
                                _engineState.value = EngineLifecycleState.READY
                                producer.trySend(InferenceStreamEvent.Error(message, recoverable = true))
                            }
                        }
                    )
                }
            } catch (cancelled: CancellationException) {
                AppDiagnosticsLogger.warn("INFERENCE", "Geração cancelada id=$generationId")
                _engineState.value = if (nativeHandle != 0L) EngineLifecycleState.READY else EngineLifecycleState.UNLOADED
                throw cancelled
            } catch (failure: Throwable) {
                AppDiagnosticsLogger.error("INFERENCE", "Geração id=$generationId falhou", failure)
                _engineState.value = if (nativeHandle != 0L) EngineLifecycleState.READY else EngineLifecycleState.UNLOADED
                producer.trySend(InferenceStreamEvent.Error(failure.message ?: "Falha na inferência nativa."))
            } finally {
                generationFinished.set(true)
                if (activeGenerationId == generationId) activeGenerationId = 0L
                producer.close()
            }
        }

        awaitClose {
            if (!generationFinished.get() && generationJob.isActive) {
                AppDiagnosticsLogger.warn("INFERENCE", "Coletor cancelado; parando geração nativa id=$generationId")
                requestGenerationStop(generationId)
                generationJob.cancel()
            }
        }
    }.buffer(Channel.UNLIMITED)

    override suspend fun stopGeneration() {
        requestActiveGenerationStop()
    }

    override fun close() {
        requestActiveGenerationStop()
        cleanupScope.launch {
            runCatching {
                operationMutex.withLock {
                    withContext(nativeDispatcher) {
                        releaseModelInternal()
                        _telemetry.value = EngineTelemetry()
                        _engineState.value = EngineLifecycleState.UNLOADED
                    }
                }
            }.onFailure { AppDiagnosticsLogger.error("NATIVE", "Falha ao liberar engine no encerramento", it) }
        }
    }

    private fun requestActiveGenerationStop() {
        val generationId = activeGenerationId
        if (generationId > 0L) requestGenerationStop(generationId)
    }

    private fun requestGenerationStop(generationId: Long) {
        if (generationId <= 0L || nativeHandle == 0L || !NativeLibrary.ensureLoaded()) return
        runCatching { nativeRequestStop(generationId) }
            .onFailure { AppDiagnosticsLogger.warn("INFERENCE", "Não foi possível enviar stop para $generationId: ${it.message}") }
    }

    private fun releaseModelInternal() {
        val handle = nativeHandle
        nativeHandle = 0L
        loadedConfig = null
        if (handle != 0L && NativeLibrary.ensureLoaded()) {
            nativeFreeModel(handle)
        }
        _loadedModel.value = null
    }

    private fun resolvePrivateModelFile(model: GgufModelSpec): File {
        if (!modelsDirectory.exists() && !modelsDirectory.mkdirs()) {
            throw IllegalStateException("Não foi possível acessar filesDir/models.")
        }
        val expectedDirectory = modelsDirectory.canonicalFile
        val hintedFile = model.localFilePath?.let(::File)
        val candidate = hintedFile?.takeIf { it.exists() } ?: File(modelsDirectory, model.fileName)
        val canonical = candidate.canonicalFile
        if (canonical.parentFile != expectedDirectory) {
            throw IllegalStateException("O caminho do GGUF não está na pasta privada filesDir/models.")
        }
        if (!canonical.isFile || canonical.length() <= 4L) {
            throw IllegalStateException(
                "GGUF não encontrado em filesDir/models/${model.fileName}. Baixe ou importe o arquivo novamente."
            )
        }
        return canonical
    }

    private fun requireValidGguf(file: File) {
        FileInputStream(file).use { input ->
            val magic = ByteArray(4)
            val read = input.read(magic)
            if (read != 4 || !magic.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) {
                throw IllegalArgumentException("${file.name} não possui um cabeçalho GGUF válido.")
            }
        }
    }

    private fun prepareChatMessages(
        messages: List<ChatMessage>,
        config: InferenceConfig
    ): Pair<Array<String>, Array<String>> {
        val roles = ArrayList<String>(messages.size + 1)
        val contents = ArrayList<String>(messages.size + 1)
        if (config.systemPrompt.isNotBlank()) {
            roles += "system"
            contents += config.systemPrompt.trim()
        }

        messages.forEach { message ->
            val text = buildString {
                if (message.content.isNotBlank()) append(message.content.trim())
                message.attachments.filterNot { it.isImage }.forEach { attachment ->
                    if (isNotEmpty()) append("\n\n")
                    append("[Arquivo anexado: ").append(attachment.name).append("]\n")
                    val extracted = attachment.extractedText.orEmpty().take(MAX_ATTACHMENT_TEXT_CHARS)
                    append(extracted.ifBlank { "O conteúdo textual deste arquivo não pôde ser extraído." })
                }
            }.trim()
            if (text.isNotBlank()) {
                roles += when (message.role) {
                    MessageRole.USER -> "user"
                    MessageRole.ASSISTANT -> "assistant"
                    MessageRole.SYSTEM -> "system"
                }
                contents += text
            }
        }
        return roles.toTypedArray() to contents.toTypedArray()
    }

    private fun KvCacheQuant.toNativeType(): Int = when (this) {
        KvCacheQuant.F16 -> 1 // GGML_TYPE_F16
        KvCacheQuant.Q8_0 -> 8 // GGML_TYPE_Q8_0
        KvCacheQuant.Q4_0 -> 2 // GGML_TYPE_Q4_0
    }

    private fun Int.toFinishReason(): FinishReason = when (this) {
        FINISH_EOS -> FinishReason.EOS_TOKEN
        FINISH_MAX_TOKENS -> FinishReason.MAX_TOKENS
        FINISH_STOPPED -> FinishReason.STOPPED_BY_USER
        FINISH_CONTEXT_FULL -> FinishReason.CONTEXT_FULL
        else -> FinishReason.EOS_TOKEN
    }

    private interface NativeCallbacks {
        fun onStarted(tokenCount: Int, promptEvalMs: Long)
        fun onThinking(text: String)
        fun onToken(text: String, totalTokens: Int, tokensPerSecond: Float)
        fun onCompleted(finishReason: Int, totalTokens: Int, tokensPerSecond: Float, durationMs: Long)
        fun onError(message: String)
    }

    private external fun nativeLoadModel(
        modelPath: String,
        gpuLayers: Int,
        useMmap: Boolean,
        useMlock: Boolean,
        diagnosticsFilePath: String,
        nativeLibraryDir: String
    ): Long

    private external fun nativeModelContextLength(handle: Long): Int
    private external fun nativeFreeModel(handle: Long)
    private external fun nativeRequestStop(generationId: Long)
    private external fun nativeSupportsGpuOffload(): Boolean

    private external fun nativeGenerate(
        handle: Long,
        generationId: Long,
        roles: Array<String>,
        contents: Array<String>,
        contextLength: Int,
        batchSize: Int,
        threads: Int,
        kvCacheType: Int,
        maxTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        repeatPenalty: Float,
        microBatchSize: Int,
        flashAttentionType: Int,
        enableThinking: Boolean,
        thinkingLevel: Int,
        callbacks: NativeCallbacks
    )

    private companion object {
        const val FINISH_EOS = 0
        const val FINISH_MAX_TOKENS = 1
        const val FINISH_STOPPED = 2
        const val FINISH_CONTEXT_FULL = 3
        const val FLASH_ATTN_AUTO = -1
        const val MAX_ATTACHMENT_TEXT_CHARS = 12_000
        val NEXT_GENERATION_ID = AtomicLong(1L)
    }
}

private object NativeLibrary {
    @Volatile
    private var attempted = false

    @Volatile
    var failure: Throwable? = null
        private set

    @Synchronized
    fun ensureLoaded(): Boolean {
        if (!attempted) {
            attempted = true
            try {
                System.loadLibrary("llama_jni")
                failure = null
            } catch (error: Throwable) {
                failure = error
            }
        }
        return failure == null
    }
}
