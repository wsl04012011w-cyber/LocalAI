package com.example.engine

import com.example.domain.model.ChatMessage
import com.example.domain.model.EngineTelemetry
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.InferenceConfig
import com.example.domain.model.MessageRole
import com.example.domain.model.ThinkingLevel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

class StubLlamaEngineAdapter : LocalInferenceEngine {

    private val engineMutex = Mutex()
    private val cancelRequested = AtomicBoolean(false)

    private val _engineState = MutableStateFlow(EngineLifecycleState.UNLOADED)
    override val engineState: StateFlow<EngineLifecycleState> = _engineState.asStateFlow()

    private val _loadedModel = MutableStateFlow<GgufModelSpec?>(null)
    override val loadedModel: StateFlow<GgufModelSpec?> = _loadedModel.asStateFlow()

    private val _telemetry = MutableStateFlow(EngineTelemetry())
    override val telemetry: StateFlow<EngineTelemetry> = _telemetry.asStateFlow()

    override val isNativeBridgeLinked: Boolean = false

    override suspend fun loadModel(model: GgufModelSpec, config: InferenceConfig): Result<Unit> {
        return engineMutex.withLock {
            try {
                _engineState.value = EngineLifecycleState.LOADING_MODEL
                delay(260L)
                _loadedModel.value = model
                val kvMb = config.estimateKvCacheMb(model)
                _telemetry.value = EngineTelemetry(
                    tokensPerSecond = 0f,
                    promptTokensUsed = 0,
                    generatedTokens = 0,
                    promptEvalMs = 0L,
                    estimatedKvCacheMb = kvMb,
                    estimatedTotalFootprintMb = model.estimatedRamMb + kvMb
                )
                _engineState.value = EngineLifecycleState.READY
                Result.success(Unit)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                _engineState.value = EngineLifecycleState.ERROR
                Result.failure(t)
            }
        }
    }

    override suspend fun unloadModel() {
        cancelRequested.set(true)
        engineMutex.withLock {
            _loadedModel.value = null
            _telemetry.value = EngineTelemetry()
            _engineState.value = EngineLifecycleState.UNLOADED
        }
    }

    override fun streamCompletion(
        messages: List<ChatMessage>,
        config: InferenceConfig
    ): Flow<InferenceStreamEvent> = flow {
        val activeModel = _loadedModel.value
        if (activeModel == null) {
            emit(
                InferenceStreamEvent.Error(
                    message = "Nenhum modelo selecionado. Carregue um modelo para conversar.",
                    recoverable = true
                )
            )
            return@flow
        }

        cancelRequested.set(false)
        _engineState.value = EngineLifecycleState.GENERATING

        val formattedPrompt = PromptFormatter.formatPrompt(messages, config, activeModel)
        val promptTokens = PromptFormatter.estimateTokens(formattedPrompt)
        val kvMb = config.estimateKvCacheMb(activeModel)

        if (promptTokens >= config.contextLength) {
            _engineState.value = EngineLifecycleState.READY
            emit(
                InferenceStreamEvent.Error(
                    message = "Limite de contexto atingido ($promptTokens / ${config.contextLength} tokens). Aumente o contexto para continuar.",
                    recoverable = true
                )
            )
            return@flow
        }

        val evalDelayMs = (90L + (promptTokens * 2L / config.threads.coerceAtLeast(1))).coerceAtMost(600L)
        delay(evalDelayMs)

        if (cancelRequested.get()) {
            _engineState.value = EngineLifecycleState.READY
            emit(
                InferenceStreamEvent.Completed(
                    finishReason = FinishReason.STOPPED_BY_USER,
                    totalTokens = 0,
                    tokensPerSecond = 0f,
                    durationMs = evalDelayMs
                )
            )
            return@flow
        }

        emit(InferenceStreamEvent.Started(promptTokens = promptTokens, promptEvalTimeMs = evalDelayMs))

        val lastUserMessage = messages.lastOrNull { it.role == MessageRole.USER }
        val responseText = buildUserFacingResponse(
            userMessage = lastUserMessage,
            model = activeModel,
            config = config
        )
        val tokenChunks = tokenizeForStreamPreview(responseText)

        val generationStartMs = System.currentTimeMillis()
        var emittedTokens = 0
        var finishReason = FinishReason.EOS_TOKEN

        try {
            for (chunk in tokenChunks) {
                if (cancelRequested.get()) {
                    finishReason = FinishReason.STOPPED_BY_USER
                    break
                }
                if (emittedTokens >= config.maxTokens) {
                    finishReason = FinishReason.MAX_TOKENS
                    break
                }
                if (promptTokens + emittedTokens >= config.contextLength) {
                    finishReason = FinishReason.CONTEXT_FULL
                    break
                }

                val perTokenMs = (38L - (config.threads * 2L)).coerceIn(14L, 38L)
                delay(perTokenMs)

                emittedTokens++
                val elapsedSec = ((System.currentTimeMillis() - generationStartMs).coerceAtLeast(1L)) / 1000f
                val tps = ((emittedTokens / elapsedSec) * 10f).roundToInt() / 10f

                _telemetry.value = EngineTelemetry(
                    tokensPerSecond = tps,
                    promptTokensUsed = promptTokens + emittedTokens,
                    generatedTokens = emittedTokens,
                    promptEvalMs = evalDelayMs,
                    estimatedKvCacheMb = kvMb,
                    estimatedTotalFootprintMb = activeModel.estimatedRamMb + kvMb
                )

                emit(
                    InferenceStreamEvent.Token(
                        text = chunk,
                        totalTokens = emittedTokens,
                        tokensPerSecond = tps
                    )
                )
            }

            val totalDurationMs = (System.currentTimeMillis() - generationStartMs).coerceAtLeast(1L)
            val finalTps = ((emittedTokens / (totalDurationMs / 1000f)) * 10f).roundToInt() / 10f
            _engineState.value = EngineLifecycleState.READY
            emit(
                InferenceStreamEvent.Completed(
                    finishReason = finishReason,
                    totalTokens = emittedTokens,
                    tokensPerSecond = finalTps,
                    durationMs = totalDurationMs
                )
            )
        } catch (ce: CancellationException) {
            _engineState.value = EngineLifecycleState.READY
            throw ce
        } catch (t: Throwable) {
            _engineState.value = EngineLifecycleState.ERROR
            emit(InferenceStreamEvent.Error(message = t.message ?: "Não foi possível gerar a resposta."))
        }
    }.flowOn(Dispatchers.Default)

    override suspend fun stopGeneration() {
        cancelRequested.set(true)
    }

    private fun tokenizeForStreamPreview(text: String): List<String> {
        val tokens = mutableListOf<String>()
        val regex = Regex("""</?think>|\S+\s*|\n+""")
        regex.findAll(text).forEach { match ->
            tokens.add(match.value)
        }
        return tokens
    }

    private fun buildUserFacingResponse(
        userMessage: ChatMessage?,
        model: GgufModelSpec,
        config: InferenceConfig
    ): String {
        val userText = userMessage?.content?.trim().orEmpty()
        val attachments = userMessage?.attachments.orEmpty()
        val useThinking = model.supportsThinking && config.thinkingLevel != ThinkingLevel.OFF

        return buildString {
            if (useThinking) {
                appendLine("<think>")
                when (config.thinkingLevel) {
                    ThinkingLevel.LOW -> {
                        appendLine("Analisando rapidamente a solicitação recebida.")
                    }
                    ThinkingLevel.MEDIUM -> {
                        appendLine("Interpretando a solicitação: \"${userText.take(60)}\".")
                        if (attachments.isNotEmpty()) {
                            appendLine("Considerando ${attachments.size} anexo(s) enviado(s) na conversa.")
                        }
                        appendLine("Organizando uma resposta clara e objetiva.")
                    }
                    ThinkingLevel.HIGH, ThinkingLevel.XHIGH -> {
                        appendLine("1. Lendo o pedido completo e verificando o contexto da conversa.")
                        if (attachments.isNotEmpty()) {
                            attachments.forEach { att ->
                                appendLine("2. Revisando anexo \"${att.name}\" (${if (att.isImage) "imagem" else "documento"}).")
                            }
                        }
                        appendLine("3. Estruturando os pontos principais com foco em precisão e clareza (nível ${config.thinkingLevel.label}).")
                    }
                    ThinkingLevel.OFF -> Unit
                }
                appendLine("</think>")
            }

            if (attachments.isNotEmpty()) {
                val names = attachments.joinToString(", ") { it.name }
                appendLine("Recebi ${attachments.size} anexo(s): $names.")
                appendLine()
            }

            if (userText.isNotEmpty()) {
                append("Entendi sua mensagem com **${model.name}**. Como posso continuar ajudando com isso?")
            } else {
                append("Anexo recebido com **${model.name}**. O que você gostaria que eu fizesse com ele?")
            }
        }
    }
}
