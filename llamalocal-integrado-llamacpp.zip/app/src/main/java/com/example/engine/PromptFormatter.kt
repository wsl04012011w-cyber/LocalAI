package com.example.engine

import com.example.domain.model.ChatMessage
import com.example.domain.model.ChatTemplateFormat
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.InferenceConfig
import com.example.domain.model.MessageRole
import com.example.domain.model.ThinkingLevel
import com.example.domain.model.ThinkingSupportMode

/**
 * Serializes messages using each model's embedded Jinja chat template behavior,
 * including reasoning effort / thinking toggle directives and attached document context.
 */
object PromptFormatter {

    fun formatPrompt(
        messages: List<ChatMessage>,
        config: InferenceConfig,
        model: GgufModelSpec? = null
    ): String {
        val cleanMessages = messages.filter { it.content.isNotBlank() || it.attachments.isNotEmpty() }
        val template = model?.defaultTemplate ?: ChatTemplateFormat.CHATML
        val thinkingEnabled = model?.supportsThinking == true && config.thinkingLevel != ThinkingLevel.OFF
        val effort = if (model?.thinkingSupport == ThinkingSupportMode.LEVELS) config.thinkingLevel else null

        return when (template) {
            ChatTemplateFormat.LLAMA3 -> formatLlama3(cleanMessages, config.systemPrompt)
            ChatTemplateFormat.CHATML -> formatChatMl(cleanMessages, config.systemPrompt)
            ChatTemplateFormat.QWEN3 -> formatQwen3(cleanMessages, config.systemPrompt, thinkingEnabled, effort)
            ChatTemplateFormat.GEMMA -> formatGemma(cleanMessages, config.systemPrompt)
            ChatTemplateFormat.PHI3 -> formatPhi3(cleanMessages, config.systemPrompt)
            ChatTemplateFormat.DEEPSEEK_R1 -> formatDeepSeekR1(cleanMessages, config.systemPrompt, thinkingEnabled)
        }
    }

    fun estimateTokens(text: String): Int {
        if (text.isBlank()) return 0
        return ((text.length + 3) / 4).coerceAtLeast(1)
    }

    private fun composeMessageText(msg: ChatMessage): String {
        val baseText = if (msg.role == MessageRole.ASSISTANT) {
            ThinkingParser.stripThinking(msg.content).trim()
        } else {
            msg.content.trim()
        }
        if (msg.attachments.isEmpty()) return baseText

        val attachmentsText = msg.attachments.joinToString("\n\n") { att ->
            when {
                att.isImage -> "[Imagem anexada: ${att.name}]"
                !att.extractedText.isNullOrBlank() -> "[Arquivo: ${att.name}]\n${att.extractedText}"
                else -> "[Arquivo anexado: ${att.name}]"
            }
        }
        return if (baseText.isEmpty()) attachmentsText else "$attachmentsText\n\n$baseText"
    }

    private fun formatLlama3(messages: List<ChatMessage>, systemPrompt: String): String = buildString {
        append("<|begin_of_text|>")
        if (systemPrompt.isNotBlank()) {
            append("<|start_header_id|>system<|end_header_id|>\n\n")
            append(systemPrompt.trim())
            append("<|eot_id|>")
        }
        messages.forEach { msg ->
            val roleTag = when (msg.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM -> "system"
            }
            append("<|start_header_id|>$roleTag<|end_header_id|>\n\n")
            append(composeMessageText(msg))
            append("<|eot_id|>")
        }
        append("<|start_header_id|>assistant<|end_header_id|>\n\n")
    }

    private fun formatChatMl(messages: List<ChatMessage>, systemPrompt: String): String = buildString {
        if (systemPrompt.isNotBlank()) {
            append("<|im_start|>system\n${systemPrompt.trim()}<|im_end|>\n")
        }
        messages.forEach { msg ->
            val roleTag = when (msg.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM -> "system"
            }
            append("<|im_start|>$roleTag\n${composeMessageText(msg)}<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }

    private fun formatQwen3(
        messages: List<ChatMessage>,
        systemPrompt: String,
        thinkingEnabled: Boolean,
        effort: ThinkingLevel?
    ): String = buildString {
        val sysContent = buildString {
            if (systemPrompt.isNotBlank()) append(systemPrompt.trim())
            if (effort != null && effort != ThinkingLevel.OFF) {
                if (isNotEmpty()) append("\n")
                append("Reasoning: ${effort.effortValue}")
            }
        }
        if (sysContent.isNotBlank()) {
            append("<|im_start|>system\n$sysContent<|im_end|>\n")
        }
        messages.forEachIndexed { index, msg ->
            val roleTag = when (msg.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "assistant"
                MessageRole.SYSTEM -> "system"
            }
            val body = composeMessageText(msg)
            val suffix = if (
                msg.role == MessageRole.USER &&
                index == messages.lastIndex &&
                !thinkingEnabled
            ) " /no_think" else ""
            append("<|im_start|>$roleTag\n$body$suffix<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
        if (!thinkingEnabled) {
            append("<think>\n\n</think>\n\n")
        }
    }

    private fun formatGemma(messages: List<ChatMessage>, systemPrompt: String): String = buildString {
        var systemPrepended = false
        messages.forEachIndexed { index, msg ->
            when (msg.role) {
                MessageRole.USER -> {
                    append("<start_of_turn>user\n")
                    if (!systemPrepended && systemPrompt.isNotBlank() && index == 0) {
                        append(systemPrompt.trim())
                        append("\n\n")
                        systemPrepended = true
                    }
                    append(composeMessageText(msg))
                    append("<end_of_turn>\n")
                }
                MessageRole.ASSISTANT -> {
                    append("<start_of_turn>model\n${composeMessageText(msg)}<end_of_turn>\n")
                }
                MessageRole.SYSTEM -> Unit
            }
        }
        append("<start_of_turn>model\n")
    }

    private fun formatPhi3(messages: List<ChatMessage>, systemPrompt: String): String = buildString {
        if (systemPrompt.isNotBlank()) {
            append("<|system|>\n${systemPrompt.trim()}<|end|>\n")
        }
        messages.forEach { msg ->
            val tag = when (msg.role) {
                MessageRole.USER -> "<|user|>"
                MessageRole.ASSISTANT -> "<|assistant|>"
                MessageRole.SYSTEM -> "<|system|>"
            }
            append("$tag\n${composeMessageText(msg)}<|end|>\n")
        }
        append("<|assistant|>\n")
    }

    private fun formatDeepSeekR1(
        messages: List<ChatMessage>,
        systemPrompt: String,
        thinkingEnabled: Boolean
    ): String = buildString {
        append("<｜begin▁of▁sentence｜>")
        if (systemPrompt.isNotBlank()) {
            append(systemPrompt.trim())
            append("\n")
        }
        messages.forEach { msg ->
            when (msg.role) {
                MessageRole.USER -> append("<｜User｜>${composeMessageText(msg)}")
                MessageRole.ASSISTANT -> append("<｜Assistant｜>${composeMessageText(msg)}<｜end▁of▁sentence｜>")
                MessageRole.SYSTEM -> Unit
            }
        }
        append("<｜Assistant｜>")
        if (thinkingEnabled) {
            append("<think>\n")
        } else {
            append("<think>\n</think>\n")
        }
    }
}

data class ParsedThinkingContent(
    val thinkingText: String,
    val isThinkingActive: Boolean,
    val answerText: String
)

object ThinkingParser {

    fun parse(rawContent: String, modelSupportsThinking: Boolean = false): ParsedThinkingContent {
        val openIdx = rawContent.indexOf("<think>")
        if (openIdx == -1) {
            val closeIdxOnly = rawContent.indexOf("</think>")
            if (modelSupportsThinking && closeIdxOnly != -1) {
                return ParsedThinkingContent(
                    thinkingText = rawContent.substring(0, closeIdxOnly).trim(),
                    isThinkingActive = false,
                    answerText = rawContent.substring(closeIdxOnly + "</think>".length).trimStart()
                )
            }
            return ParsedThinkingContent(
                thinkingText = "",
                isThinkingActive = false,
                answerText = rawContent
            )
        }

        val afterOpen = openIdx + "<think>".length
        val closeIdx = rawContent.indexOf("</think>", startIndex = afterOpen)
        return if (closeIdx == -1) {
            ParsedThinkingContent(
                thinkingText = rawContent.substring(afterOpen).trimStart(),
                isThinkingActive = true,
                answerText = rawContent.substring(0, openIdx).trim()
            )
        } else {
            val before = rawContent.substring(0, openIdx).trim()
            val after = rawContent.substring(closeIdx + "</think>".length).trimStart()
            val combinedAnswer = listOf(before, after).filter { it.isNotEmpty() }.joinToString("\n\n")
            ParsedThinkingContent(
                thinkingText = rawContent.substring(afterOpen, closeIdx).trim(),
                isThinkingActive = false,
                answerText = combinedAnswer
            )
        }
    }

    fun stripThinking(rawContent: String): String {
        val parsed = parse(rawContent)
        return if (parsed.thinkingText.isNotEmpty() || parsed.isThinkingActive) {
            parsed.answerText
        } else {
            rawContent
        }
    }
}
