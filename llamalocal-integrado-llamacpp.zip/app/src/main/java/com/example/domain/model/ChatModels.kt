package com.example.domain.model

import java.util.UUID

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM
}

enum class MessageStatus {
    QUEUED,
    STREAMING,
    COMPLETED,
    STOPPED,
    ERROR
}

data class ChatAttachment(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val mimeType: String,
    val uriString: String,
    val isImage: Boolean,
    val extractedText: String? = null,
    val sizeBytes: Long = 0L
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val attachments: List<ChatAttachment> = emptyList(),
    val timestampMs: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.COMPLETED,
    val tokenCount: Int = 0,
    val tokensPerSecond: Float = 0f,
    val generationDurationMs: Long = 0L,
    val thinkingDurationMs: Long = 0L,
    val modelName: String? = null
)

data class ConversationSession(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    val updatedAtMs: Long = System.currentTimeMillis(),
    val messages: List<ChatMessage> = emptyList(),
    val modelId: String? = null
)

enum class GgufQuantization(
    val label: String,
    val bitsPerWeight: Float
) {
    IQ4_XS("IQ4_XS", 4.25f),
    Q4_0("Q4_0", 4.5f),
    Q4_K_M("Q4_K_M", 4.85f),
    Q5_K_M("Q5_K_M", 5.65f),
    Q8_0("Q8_0", 8.5f),
    F16("F16", 16.0f)
}

enum class ThinkingSupportMode {
    NONE,
    BINARY,
    LEVELS
}

enum class ThinkingLevel(
    val label: String,
    val effortValue: String
) {
    OFF("Off", "off"),
    LOW("Low", "low"),
    MEDIUM("Médio", "medium"),
    HIGH("Alto", "high"),
    XHIGH("XHigh", "xhigh")
}

enum class ChatTemplateFormat(
    val displayName: String,
    val stopToken: String,
    val defaultJinja: String
) {
    LLAMA3(
        displayName = "Llama 3",
        stopToken = "<|eot_id|>",
        defaultJinja = "{{ bos_token }}{% for m in messages %}<|start_header_id|>{{ m['role'] }}<|end_header_id|>\n\n{{ m['content'] | trim }}<|eot_id|>{% endfor %}{% if add_generation_prompt %}<|start_header_id|>assistant<|end_header_id|>\n\n{% endif %}"
    ),
    CHATML(
        displayName = "ChatML",
        stopToken = "<|im_end|>",
        defaultJinja = "{% for m in messages %}<|im_start|>{{ m['role'] }}\n{{ m['content'] }}<|im_end|>\n{% endfor %}{% if add_generation_prompt %}<|im_start|>assistant\n{% endif %}"
    ),
    QWEN3(
        displayName = "Qwen3",
        stopToken = "<|im_end|>",
        defaultJinja = "{% for m in messages %}<|im_start|>{{ m['role'] }}\n{{ m['content'] }}<|im_end|>\n{% endfor %}{% if add_generation_prompt %}<|im_start|>assistant\n{% if reasoning_effort == 'off' %}<think>\n\n</think>\n\n{% endif %}{% endif %}"
    ),
    GEMMA(
        displayName = "Gemma",
        stopToken = "<end_of_turn>",
        defaultJinja = "{% for m in messages %}<start_of_turn>{{ 'model' if m['role'] == 'assistant' else m['role'] }}\n{{ m['content'] | trim }}<end_of_turn>\n{% endfor %}{% if add_generation_prompt %}<start_of_turn>model\n{% endif %}"
    ),
    PHI3(
        displayName = "Phi-3",
        stopToken = "<|end|>",
        defaultJinja = "{% for m in messages %}<|{{ m['role'] }}|>\n{{ m['content'] }}<|end|>\n{% endfor %}{% if add_generation_prompt %}<|assistant|>\n{% endif %}"
    ),
    DEEPSEEK_R1(
        displayName = "DeepSeek-R1",
        stopToken = "<｜end▁of▁sentence｜>",
        defaultJinja = "{{ bos_token }}{% if system_message %}{{ system_message }}{% endif %}{% for m in messages %}{% if m['role'] == 'user' %}<｜User｜>{{ m['content'] }}{% elif m['role'] == 'assistant' %}<｜Assistant｜>{{ m['content'] }}<｜end▁of▁sentence｜>{% endif %}{% endfor %}{% if add_generation_prompt %}<｜Assistant｜>{% if enable_thinking %}<think>\n{% endif %}{% endif %}"
    )
}

enum class KvCacheQuant(
    val label: String,
    val bytesPerElement: Float
) {
    F16("F16", 2.0f),
    Q8_0("Q8_0", 1.0f),
    Q4_0("Q4_0", 0.5f)
}

enum class ModelOrigin {
    CATALOG,
    DEVICE_STORAGE
}

data class GgufModelSpec(
    val id: String,
    val name: String,
    val architecture: String,
    val parameterLabel: String,
    val quantization: GgufQuantization,
    val fileName: String,
    val fileSizeMb: Int,
    val estimatedRamMb: Int,
    val maxContextLength: Int,
    val defaultTemplate: ChatTemplateFormat,
    val jinjaTemplate: String = defaultTemplate.defaultJinja,
    val thinkingSupport: ThinkingSupportMode = ThinkingSupportMode.NONE,
    val supportsVision: Boolean = false,
    val isDownloaded: Boolean = false,
    val localFilePath: String? = null,
    val origin: ModelOrigin = ModelOrigin.CATALOG,
    val downloadUrl: String? = null,
    val repositoryUrl: String? = null,
    val description: String
) {
    val supportsThinking: Boolean
        get() = thinkingSupport != ThinkingSupportMode.NONE
}

data class ModelDownloadProgress(
    val modelId: String,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val etaSeconds: Long,
    val isImporting: Boolean = false
) {
    val progress: Float
        get() = if (totalBytes > 0L) {
            (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
        } else 0f

    val remainingBytes: Long
        get() = (totalBytes - downloadedBytes).coerceAtLeast(0L)
}

object EngineLimits {
    const val MIN_CONTEXT = 512
    const val DEFAULT_MAX_MODEL_CONTEXT = 131_072
    const val MIN_BATCH = 64
    const val MAX_BATCH = 4096
    const val MIN_MAX_TOKENS = 128
    const val MIN_THREADS = 1
    const val MAX_THREADS = 16
    const val MIN_GPU_LAYERS = 0
    const val MAX_GPU_LAYERS = 99
    const val MIN_TEMP = 0.0f
    const val MAX_TEMP = 2.0f
}

data class InferenceConfig(
    val contextLength: Int = 4096,
    val threads: Int = 4,
    val batchSize: Int = 512,
    val gpuLayers: Int = 0,
    val useMmap: Boolean = true,
    val useMlock: Boolean = false,
    val kvCacheQuant: KvCacheQuant = KvCacheQuant.Q8_0,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.1f,
    val maxTokens: Int = 2048,
    val thinkingLevel: ThinkingLevel = ThinkingLevel.MEDIUM,
    val systemPrompt: String = "Você é o Ayr off, um assistente de IA útil e direto executado offline no dispositivo."
) {
    fun estimateKvCacheMb(model: GgufModelSpec?): Int {
        val layerFactor = when {
            model == null -> 28f
            model.parameterLabel.contains("1.") || model.parameterLabel.contains("2B") -> 24f
            model.parameterLabel.contains("3B") -> 28f
            model.parameterLabel.contains("7B") || model.parameterLabel.contains("8B") -> 32f
            else -> 28f
        }
        val bytes = 2.0 * layerFactor * 1024.0 * contextLength * kvCacheQuant.bytesPerElement
        return (bytes / (1024.0 * 1024.0)).toInt().coerceAtLeast(16)
    }
}

data class DeviceMemoryInfo(
    val totalRamMb: Int,
    val availableRamMb: Int,
    val cpuCores: Int,
    val primaryAbi: String,
    val isArm64: Boolean
)

data class EngineTelemetry(
    val tokensPerSecond: Float = 0f,
    val promptTokensUsed: Int = 0,
    val generatedTokens: Int = 0,
    val promptEvalMs: Long = 0L,
    val estimatedKvCacheMb: Int = 0,
    val estimatedTotalFootprintMb: Int = 0
)
