package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.ChatAttachment
import com.example.domain.model.ChatMessage
import com.example.domain.model.MessageRole
import com.example.domain.model.MessageStatus
import com.example.engine.ThinkingParser
import com.example.ui.theme.JetBrainsMonoFontFamily

private sealed interface ContentSegment {
    data class TextBlock(val text: String) : ContentSegment
    data class CodeBlock(val language: String, val code: String) : ContentSegment
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MessageBubble(
    message: ChatMessage,
    isLastAssistantMessage: Boolean,
    isEngineBusy: Boolean,
    modelSupportsThinking: Boolean = false,
    onCopy: (String) -> Unit,
    onRegenerate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == MessageRole.USER
    val parsed = remember(message.content, modelSupportsThinking) {
        ThinkingParser.parse(message.content, modelSupportsThinking)
    }
    val segments = remember(parsed.answerText) { parseMarkdownSegments(parsed.answerText) }

    val cursorTransition = rememberInfiniteTransition(label = "streamCursor")
    val cursorAlpha by cursorTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(tween(450), RepeatMode.Reverse),
        label = "cursorAlpha"
    )

    if (isUser) {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalAlignment = Alignment.End
        ) {
            if (message.attachments.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .padding(start = 52.dp, bottom = if (message.content.isNotBlank()) 6.dp else 0.dp)
                ) {
                    message.attachments.forEach { attachment ->
                        MessageAttachmentChip(attachment = attachment)
                    }
                }
            }

            if (message.content.isNotBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .widthIn(max = 520.dp)
                        .padding(start = 52.dp)
                        .testTag("user_message_bubble")
                ) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp)
                    )
                }
            }
        }
    } else {
        Column(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("assistant_message_bubble")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.llama_local_icon_1795437762783),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = message.modelName ?: "Ayr off",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (message.status == MessageStatus.STOPPED) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• interrompido",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                } else if (message.status == MessageStatus.ERROR) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "• erro",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            if (message.status == MessageStatus.QUEUED && message.content.isBlank()) {
                Text(
                    text = "Analisando…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                if (parsed.thinkingText.isNotEmpty() || parsed.isThinkingActive) {
                    ThinkingBox(
                        thinkingText = parsed.thinkingText,
                        isStreamingThinking = parsed.isThinkingActive && message.status == MessageStatus.STREAMING,
                        durationMs = message.thinkingDurationMs,
                        pulseAlpha = cursorAlpha
                    )
                    if (parsed.answerText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }

                if (parsed.answerText.isNotBlank()) {
                    segments.forEachIndexed { idx, segment ->
                        when (segment) {
                            is ContentSegment.TextBlock -> {
                                val suffix = if (
                                    message.status == MessageStatus.STREAMING &&
                                    !parsed.isThinkingActive &&
                                    idx == segments.lastIndex
                                ) " ▍" else ""
                                Text(
                                    text = segment.text + suffix,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (message.status == MessageStatus.ERROR) {
                                        MaterialTheme.colorScheme.error
                                    } else {
                                        MaterialTheme.colorScheme.onBackground
                                    },
                                    modifier = if (suffix.isNotEmpty()) {
                                        Modifier.alpha(0.95f + (cursorAlpha * 0.05f))
                                    } else Modifier
                                )
                            }

                            is ContentSegment.CodeBlock -> {
                                Spacer(modifier = Modifier.height(10.dp))
                                CodeSnippetCard(
                                    language = segment.language,
                                    code = segment.code,
                                    onCopy = { onCopy(segment.code) }
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }

            if (message.status != MessageStatus.QUEUED && message.status != MessageStatus.STREAMING) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (message.tokensPerSecond > 0f) {
                            "${message.tokensPerSecond} tok/s"
                        } else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (message.content.isNotBlank()) {
                            IconButton(
                                onClick = { onCopy(parsed.answerText.ifBlank { message.content }) },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("copy_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ContentCopy,
                                    contentDescription = stringResource(R.string.cd_copy_message),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                        if (isLastAssistantMessage && !isEngineBusy) {
                            IconButton(
                                onClick = onRegenerate,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("regenerate_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = stringResource(R.string.cd_regenerate),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageAttachmentChip(attachment: ChatAttachment) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (attachment.isImage) Icons.Rounded.Image else Icons.Rounded.Description,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = attachment.name,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 180.dp)
        )
    }
}

@Composable
private fun ThinkingBox(
    thinkingText: String,
    isStreamingThinking: Boolean,
    durationMs: Long,
    pulseAlpha: Float
) {
    var expanded by remember { mutableStateOf(true) }

    LaunchedEffect(isStreamingThinking) {
        if (isStreamingThinking) {
            expanded = true
        }
    }

    val headerLabel = when {
        isStreamingThinking -> "Pensando…"
        durationMs > 0L -> {
            val sec = String.format("%.1fs", durationMs / 1000f)
            "Pensou por $sec"
        }
        else -> "Raciocínio"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(14.dp)
            )
            .testTag("thinking_box")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
                .padding(horizontal = 12.dp, vertical = 10.dp)
                .testTag("thinking_box_header"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier
                        .size(15.dp)
                        .alpha(if (isStreamingThinking) pulseAlpha else 1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = headerLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = if (expanded) "Recolher raciocínio" else "Expandir raciocínio",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(),
            exit = shrinkVertically()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min)
                    .padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(1.dp))
                        .background(MaterialTheme.colorScheme.outline)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (isStreamingThinking) "$thinkingText ▍" else thinkingText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun CodeSnippetCard(
    language: String,
    code: String,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(14.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceContainer)
                .padding(horizontal = 12.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = language.ifBlank { "code" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            IconButton(
                onClick = onCopy,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Rounded.ContentCopy,
                    contentDescription = stringResource(R.string.cd_copy_message),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
        Text(
            text = code,
            style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFontFamily),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        )
    }
}

private fun parseMarkdownSegments(raw: String): List<ContentSegment> {
    if (!raw.contains("```")) {
        return listOf(ContentSegment.TextBlock(raw))
    }
    val segments = mutableListOf<ContentSegment>()
    var cursor = 0
    val fenceRegex = Regex("""```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)(```|$)""")
    fenceRegex.findAll(raw).forEach { match ->
        if (match.range.first > cursor) {
            val before = raw.substring(cursor, match.range.first).trim()
            if (before.isNotEmpty()) segments.add(ContentSegment.TextBlock(before))
        }
        val lang = match.groupValues[1]
        val code = match.groupValues[2].trimEnd()
        segments.add(ContentSegment.CodeBlock(language = lang, code = code))
        cursor = match.range.last + 1
    }
    if (cursor < raw.length) {
        val tail = raw.substring(cursor).trim()
        if (tail.isNotEmpty()) segments.add(ContentSegment.TextBlock(tail))
    }
    return if (segments.isEmpty()) listOf(ContentSegment.TextBlock(raw)) else segments
}
