package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.domain.model.ChatAttachment
import com.example.domain.model.MessageRole
import com.example.domain.model.ThinkingLevel
import com.example.domain.model.ThinkingSupportMode
import com.example.state.AppDestination
import com.example.state.LlamaChatAction
import com.example.state.LlamaChatUiState
import com.example.ui.components.MessageBubble
import com.example.ui.components.formatTokenCount

@Composable
fun ChatScreen(
    uiState: LlamaChatUiState,
    onAction: (LlamaChatAction) -> Unit,
    modifier: Modifier = Modifier
) {
    val messages = uiState.activeSession?.messages.orEmpty()
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onAction(LlamaChatAction.AttachFileUri(uri, isImage = true))
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onAction(LlamaChatAction.AttachFileUri(uri, isImage = false))
        }
    }

    val isNearBottom by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            layoutInfo.totalItemsCount == 0 || lastVisible >= layoutInfo.totalItemsCount - 2
        }
    }

    val lastContentLength = messages.lastOrNull()?.content?.length ?: 0
    LaunchedEffect(messages.size, lastContentLength) {
        if (messages.isNotEmpty() && isNearBottom) {
            listState.scrollToItem(messages.lastIndex)
        }
    }

    val lastAssistantId = remember(messages) {
        messages.lastOrNull { it.role == MessageRole.ASSISTANT }?.id
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            if (messages.isEmpty()) {
                MinimalEmptyChatState(
                    uiState = uiState,
                    onQuickModelTap = { onAction(LlamaChatAction.SelectDestination(AppDestination.MODELS)) }
                )
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxSize()
                ) {
                    itemsIndexed(messages, key = { _, msg -> msg.id }) { _, message ->
                        MessageBubble(
                            message = message,
                            isLastAssistantMessage = message.id == lastAssistantId,
                            isEngineBusy = uiState.isGenerating || uiState.isLoadingModel,
                            modelSupportsThinking = uiState.loadedModel?.supportsThinking == true,
                            onCopy = { text -> clipboard.setText(AnnotatedString(text)) },
                            onRegenerate = { onAction(LlamaChatAction.RegenerateLastResponse) }
                        )
                    }
                }
            }
        }

        MinimalComposerCard(
            uiState = uiState,
            onDraftChange = { onAction(LlamaChatAction.UpdateDraft(it)) },
            onSend = { onAction(LlamaChatAction.SendPrompt()) },
            onStop = { onAction(LlamaChatAction.StopGeneration) },
            onOpenModels = { onAction(LlamaChatAction.SelectDestination(AppDestination.MODELS)) },
            onOpenContextSlider = { onAction(LlamaChatAction.SetContextSheetOpen(true)) },
            onToggleBinaryThinking = { onAction(LlamaChatAction.ToggleBinaryThinking) },
            onSelectThinkingLevel = { level -> onAction(LlamaChatAction.UpdateThinkingLevel(level)) },
            onOpenAttachments = { onAction(LlamaChatAction.SetAttachmentSheetOpen(true)) },
            onRemoveAttachment = { id -> onAction(LlamaChatAction.RemovePendingAttachment(id)) }
        )
    }

    if (uiState.isAttachmentSheetOpen) {
        AttachmentPickerSheet(
            supportsVision = uiState.loadedModel?.supportsVision == true,
            onPickImage = {
                imagePickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onPickDocument = {
                documentPickerLauncher.launch(
                    arrayOf("application/pdf", "text/*", "application/json", "application/xml")
                )
            },
            onDismiss = { onAction(LlamaChatAction.SetAttachmentSheetOpen(false)) }
        )
    }
}

@Composable
private fun MinimalEmptyChatState(
    uiState: LlamaChatUiState,
    onQuickModelTap: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.llama_local_icon_1795437762783),
            contentDescription = stringResource(R.string.cd_app_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .clickable(onClick = onQuickModelTap)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Qual é o plano para hoje?",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        uiState.loadedModel?.let { model ->
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${model.name} • ${model.parameterLabel}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun MinimalComposerCard(
    uiState: LlamaChatUiState,
    onDraftChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onOpenModels: () -> Unit,
    onOpenContextSlider: () -> Unit,
    onToggleBinaryThinking: () -> Unit,
    onSelectThinkingLevel: (ThinkingLevel) -> Unit,
    onOpenAttachments: () -> Unit,
    onRemoveAttachment: (String) -> Unit
) {
    var thinkingMenuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            shape = RoundedCornerShape(26.dp),
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outlineVariant,
                    shape = RoundedCornerShape(26.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 12.dp, top = 14.dp, bottom = 10.dp)
            ) {
                if (uiState.pendingAttachments.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(bottom = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        uiState.pendingAttachments.forEach { attachment ->
                            PendingAttachmentChip(
                                attachment = attachment,
                                onRemove = { onRemoveAttachment(attachment.id) }
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 6.dp)
                ) {
                    if (uiState.composerDraft.isEmpty()) {
                        Text(
                            text = "Mensagem para ${stringResource(R.string.app_name)}",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // ImeAction.Default keeps the keyboard's Enter key as a line break instead of sending
                    BasicTextField(
                        value = uiState.composerDraft,
                        onValueChange = onDraftChange,
                        enabled = !uiState.isLoadingModel,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        maxLines = 6,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_prompt_input")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ComposerModePill(
                            icon = Icons.Rounded.Memory,
                            label = uiState.loadedModel?.parameterLabel ?: "Modelo",
                            active = uiState.loadedModel != null,
                            onClick = onOpenModels,
                            testTag = "composer_models_pill"
                        )
                        ComposerModePill(
                            icon = Icons.Rounded.Tune,
                            label = "${formatTokenCount(uiState.config.contextLength)} ctx",
                            active = false,
                            onClick = onOpenContextSlider,
                            testTag = "composer_context_pill"
                        )

                        val loadedModel = uiState.loadedModel
                        if (loadedModel != null && loadedModel.supportsThinking) {
                            val thinkingActive = uiState.config.thinkingLevel != ThinkingLevel.OFF
                            if (loadedModel.thinkingSupport == ThinkingSupportMode.LEVELS) {
                                Box {
                                    ComposerModePill(
                                        icon = Icons.Rounded.AutoAwesome,
                                        label = if (thinkingActive) {
                                            "Think • ${uiState.config.thinkingLevel.label}"
                                        } else {
                                            "Think • Off"
                                        },
                                        active = thinkingActive,
                                        onClick = { thinkingMenuExpanded = true },
                                        testTag = "composer_thinking_pill"
                                    )
                                    DropdownMenu(
                                        expanded = thinkingMenuExpanded,
                                        onDismissRequest = { thinkingMenuExpanded = false },
                                        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                    ) {
                                        ThinkingLevel.entries.forEach { level ->
                                            val isSelected = uiState.config.thinkingLevel == level
                                            DropdownMenuItem(
                                                text = { Text(level.label) },
                                                trailingIcon = {
                                                    if (isSelected) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.Check,
                                                            contentDescription = null,
                                                            tint = MaterialTheme.colorScheme.primary
                                                        )
                                                    }
                                                },
                                                onClick = {
                                                    onSelectThinkingLevel(level)
                                                    thinkingMenuExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            } else {
                                ComposerModePill(
                                    icon = Icons.Rounded.AutoAwesome,
                                    label = if (thinkingActive) "Think" else "Think Off",
                                    active = thinkingActive,
                                    onClick = onToggleBinaryThinking,
                                    testTag = "composer_thinking_pill"
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onOpenAttachments,
                            enabled = !uiState.isGenerating && !uiState.isLoadingModel,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("composer_attach_button")
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .border(
                                        width = 1.2.dp,
                                        color = MaterialTheme.colorScheme.outline,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = stringResource(R.string.cd_attach_file),
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        FilledIconButton(
                            onClick = {
                                if (uiState.isGenerating) onStop() else onSend()
                            },
                            enabled = uiState.isGenerating || uiState.canSendPrompt,
                            shape = CircleShape,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = when {
                                    uiState.isGenerating -> MaterialTheme.colorScheme.error
                                    uiState.canSendPrompt -> MaterialTheme.colorScheme.primary
                                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                                },
                                contentColor = when {
                                    uiState.isGenerating -> MaterialTheme.colorScheme.onError
                                    uiState.canSendPrompt -> MaterialTheme.colorScheme.onPrimary
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            ),
                            modifier = Modifier
                                .size(42.dp)
                                .testTag("send_or_stop_button")
                        ) {
                            Icon(
                                imageVector = if (uiState.isGenerating) {
                                    Icons.Rounded.Stop
                                } else {
                                    Icons.AutoMirrored.Rounded.Send
                                },
                                contentDescription = if (uiState.isGenerating) {
                                    stringResource(R.string.cd_stop_generation)
                                } else {
                                    stringResource(R.string.cd_send_prompt)
                                },
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingAttachmentChip(
    attachment: ChatAttachment,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(12.dp)
            )
            .padding(start = 10.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (attachment.isImage) Icons.Rounded.Image else Icons.Rounded.Description,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = attachment.name,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.widthIn(max = 150.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Icon(
            imageVector = Icons.Rounded.Close,
            contentDescription = "Remover anexo",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .clickable(onClick = onRemove)
                .padding(2.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AttachmentPickerSheet(
    supportsVision: Boolean,
    onPickImage: () -> Unit,
    onPickDocument: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Anexar ao chat",
                style = MaterialTheme.typography.titleMedium
            )

            AttachmentOptionRow(
                icon = Icons.Rounded.Image,
                title = "Imagem",
                subtitle = if (supportsVision) {
                    "Selecionar foto da galeria"
                } else {
                    "Indisponível para o modelo atual"
                },
                enabled = supportsVision,
                onClick = onPickImage,
                testTag = "attach_image_option"
            )

            AttachmentOptionRow(
                icon = Icons.Rounded.Description,
                title = "Documento (PDF, TXT, Código)",
                subtitle = "TXT/código: prévia de 12 mil caracteres. PDF: nome e páginas.",
                enabled = true,
                onClick = onPickDocument,
                testTag = "attach_document_option"
            )
        }
    }
}

@Composable
private fun AttachmentOptionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.48f)
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ComposerModePill(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val bgColor = if (active) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.surfaceContainer
    }
    val borderColor = if (active) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
    } else {
        MaterialTheme.colorScheme.outline
    }
    val contentColor = if (active) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bgColor)
            .border(width = 1.dp, color = borderColor, shape = RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = contentColor,
            maxLines = 1
        )
    }
}
