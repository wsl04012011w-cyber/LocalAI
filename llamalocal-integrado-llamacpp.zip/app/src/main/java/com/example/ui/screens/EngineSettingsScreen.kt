package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.EngineLimits
import com.example.domain.model.KvCacheQuant
import com.example.state.LlamaChatAction
import com.example.state.LlamaChatUiState
import com.example.ui.components.formatTokenCount
import com.example.ui.theme.JetBrainsMonoFontFamily
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EngineSettingsScreen(
    uiState: LlamaChatUiState,
    onAction: (LlamaChatAction) -> Unit,
    modifier: Modifier = Modifier
) {
    val config = uiState.config
    val maxModelCtx = uiState.maxModelContext.coerceAtLeast(EngineLimits.MIN_CONTEXT)

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
        ) {
            item {
                SectionCard(title = "Contexto e Desempenho") {
                    val ctxStep = if (maxModelCtx >= 32768) 512 else 256
                    SliderParamRow(
                        label = "Janela de contexto",
                        valueText = "${formatTokenCount(config.contextLength)} / ${formatTokenCount(maxModelCtx)}",
                        value = config.contextLength.coerceIn(EngineLimits.MIN_CONTEXT, maxModelCtx).toFloat(),
                        valueRange = EngineLimits.MIN_CONTEXT.toFloat()..maxModelCtx.toFloat(),
                        onValueChange = { raw ->
                            val snapped = ((raw / ctxStep).roundToInt() * ctxStep)
                                .coerceIn(EngineLimits.MIN_CONTEXT, maxModelCtx)
                            onAction(LlamaChatAction.UpdateContextLength(snapped))
                        },
                        testTag = "slider_context"
                    )

                    SliderParamRow(
                        label = "Limite de resposta",
                        valueText = "${formatTokenCount(config.maxTokens)} / ${formatTokenCount(maxModelCtx)}",
                        value = config.maxTokens.coerceIn(EngineLimits.MIN_MAX_TOKENS, maxModelCtx).toFloat(),
                        valueRange = EngineLimits.MIN_MAX_TOKENS.toFloat()..maxModelCtx.toFloat(),
                        onValueChange = { raw ->
                            val genStep = if (maxModelCtx >= 32768) 256 else 128
                            val snapped = ((raw / genStep).roundToInt() * genStep)
                                .coerceIn(EngineLimits.MIN_MAX_TOKENS, maxModelCtx)
                            onAction(LlamaChatAction.UpdateMaxTokens(snapped))
                        },
                        testTag = "slider_max_tokens"
                    )

                    SliderParamRow(
                        label = "Tamanho do lote",
                        valueText = "${config.batchSize}",
                        value = config.batchSize.coerceIn(EngineLimits.MIN_BATCH, EngineLimits.MAX_BATCH).toFloat(),
                        valueRange = EngineLimits.MIN_BATCH.toFloat()..EngineLimits.MAX_BATCH.toFloat(),
                        onValueChange = { raw ->
                            val snapped = ((raw / 64f).roundToInt() * 64)
                                .coerceIn(EngineLimits.MIN_BATCH, EngineLimits.MAX_BATCH)
                            onAction(LlamaChatAction.UpdateBatchSize(snapped))
                        },
                        testTag = "slider_batch"
                    )

                    SliderParamRow(
                        label = "Núcleos de CPU",
                        valueText = "${config.threads}",
                        value = config.threads.coerceIn(EngineLimits.MIN_THREADS, EngineLimits.MAX_THREADS).toFloat(),
                        valueRange = EngineLimits.MIN_THREADS.toFloat()..EngineLimits.MAX_THREADS.toFloat(),
                        steps = EngineLimits.MAX_THREADS - EngineLimits.MIN_THREADS - 1,
                        onValueChange = { onAction(LlamaChatAction.UpdateThreads(it.roundToInt())) },
                        testTag = "slider_threads"
                    )

                    Text(
                        text = "Backend nativo desta versão: CPU (arm64-v8a). Offload para GPU e entrada de imagens ainda não estão incluídos.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                SectionCard(title = "Memória") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Precisão do contexto", style = MaterialTheme.typography.bodyMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            KvCacheQuant.entries.forEach { quant ->
                                FilterChip(
                                    selected = config.kvCacheQuant == quant,
                                    onClick = { onAction(LlamaChatAction.UpdateKvCacheQuant(quant)) },
                                    label = { Text(quant.label) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    CompactSwitchRow(
                        title = "Mapeamento direto",
                        checked = config.useMmap,
                        onCheckedChange = { onAction(LlamaChatAction.ToggleMmap(it)) }
                    )
                    CompactSwitchRow(
                        title = "Fixar modelo na RAM",
                        checked = config.useMlock,
                        onCheckedChange = { onAction(LlamaChatAction.ToggleMlock(it)) }
                    )
                }
            }

            item {
                SectionCard(title = "Estilo de Resposta") {
                    SliderParamRow(
                        label = "Temperatura",
                        valueText = String.format("%.2f", config.temperature),
                        value = config.temperature,
                        valueRange = EngineLimits.MIN_TEMP..EngineLimits.MAX_TEMP,
                        onValueChange = {
                            val rounded = (it * 20f).roundToInt() / 20f
                            onAction(LlamaChatAction.UpdateTemperature(rounded))
                        },
                        testTag = "slider_temperature"
                    )
                    SliderParamRow(
                        label = "Top-P",
                        valueText = String.format("%.2f", config.topP),
                        value = config.topP,
                        valueRange = 0.05f..1.00f,
                        onValueChange = {
                            val rounded = (it * 20f).roundToInt() / 20f
                            onAction(LlamaChatAction.UpdateTopP(rounded))
                        },
                        testTag = "slider_top_p"
                    )
                    SliderParamRow(
                        label = "Top-K",
                        valueText = "${config.topK}",
                        value = config.topK.toFloat(),
                        valueRange = 1f..200f,
                        onValueChange = { onAction(LlamaChatAction.UpdateTopK(it.roundToInt())) },
                        testTag = "slider_top_k"
                    )
                    SliderParamRow(
                        label = "Penalidade de repetição",
                        valueText = String.format("%.2f", config.repeatPenalty),
                        value = config.repeatPenalty,
                        valueRange = 0.80f..2.00f,
                        onValueChange = {
                            val rounded = (it * 20f).roundToInt() / 20f
                            onAction(LlamaChatAction.UpdateRepeatPenalty(rounded))
                        },
                        testTag = "slider_repeat_penalty"
                    )
                }
            }

            item {
                SectionCard(title = "Instruções do Assistente") {
                    OutlinedTextField(
                        value = config.systemPrompt,
                        onValueChange = { onAction(LlamaChatAction.UpdateSystemPrompt(it)) },
                        minLines = 2,
                        maxLines = 5,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("system_prompt_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { onAction(LlamaChatAction.ResetDefaultConfig) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reset_engine_config_button")
                    ) {
                        Text("Restaurar Padrões")
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceContainer,
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(18.dp)
            )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SliderParamRow(
    label: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                color = MaterialTheme.colorScheme.primary
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun CompactSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
