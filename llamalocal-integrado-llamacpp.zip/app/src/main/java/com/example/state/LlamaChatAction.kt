package com.example.state

import android.net.Uri
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.KvCacheQuant
import com.example.domain.model.ThinkingLevel

sealed interface LlamaChatAction {
    data class SelectDestination(val destination: AppDestination) : LlamaChatAction
    data class UpdateDraft(val text: String) : LlamaChatAction
    data class SendPrompt(val overrideText: String? = null) : LlamaChatAction
    data object StopGeneration : LlamaChatAction
    data object RegenerateLastResponse : LlamaChatAction

    data class LoadModel(val model: GgufModelSpec) : LlamaChatAction
    data object ReloadActiveModel : LlamaChatAction
    data object UnloadModel : LlamaChatAction
    data class DownloadModel(val model: GgufModelSpec) : LlamaChatAction
    data class CancelDownload(val modelId: String) : LlamaChatAction
    data class DeleteStoredModel(val model: GgufModelSpec) : LlamaChatAction
    data class ImportGgufUri(val uri: Uri) : LlamaChatAction
    data object RefreshModels : LlamaChatAction

    data object ToggleBinaryThinking : LlamaChatAction
    data class UpdateThinkingLevel(val level: ThinkingLevel) : LlamaChatAction
    data class SetAttachmentSheetOpen(val open: Boolean) : LlamaChatAction
    data class AttachFileUri(val uri: Uri, val isImage: Boolean) : LlamaChatAction
    data class RemovePendingAttachment(val attachmentId: String) : LlamaChatAction

    data object CreateNewSession : LlamaChatAction
    data class SelectSession(val sessionId: String) : LlamaChatAction
    data class DeleteSession(val sessionId: String) : LlamaChatAction

    data class SetContextSheetOpen(val open: Boolean) : LlamaChatAction
    data object DismissStatusBanner : LlamaChatAction

    // Unrestricted parameter actions (bounded only by model architecture limits)
    data class UpdateContextLength(val nCtx: Int) : LlamaChatAction
    data class UpdateThreads(val threads: Int) : LlamaChatAction
    data class UpdateBatchSize(val nBatch: Int) : LlamaChatAction
    data class UpdateGpuLayers(val layers: Int) : LlamaChatAction
    data class ToggleMmap(val enabled: Boolean) : LlamaChatAction
    data class ToggleMlock(val enabled: Boolean) : LlamaChatAction
    data class UpdateKvCacheQuant(val quant: KvCacheQuant) : LlamaChatAction
    data class UpdateTemperature(val temperature: Float) : LlamaChatAction
    data class UpdateTopP(val topP: Float) : LlamaChatAction
    data class UpdateTopK(val topK: Int) : LlamaChatAction
    data class UpdateRepeatPenalty(val penalty: Float) : LlamaChatAction
    data class UpdateMaxTokens(val maxTokens: Int) : LlamaChatAction
    data class UpdateSystemPrompt(val prompt: String) : LlamaChatAction
    data object ResetDefaultConfig : LlamaChatAction
}
