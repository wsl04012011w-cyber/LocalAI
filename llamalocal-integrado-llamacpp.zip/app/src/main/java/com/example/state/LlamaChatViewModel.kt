package com.example.state

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DeviceHardwareInspector
import com.example.data.GgufRepository
import com.example.data.LocalModelStorageManager
import com.example.domain.model.ChatAttachment
import com.example.domain.model.ChatMessage
import com.example.domain.model.ConversationSession
import com.example.domain.model.EngineLimits
import com.example.domain.model.EngineTelemetry
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.InferenceConfig
import com.example.domain.model.MessageRole
import com.example.domain.model.MessageStatus
import com.example.domain.model.ModelDownloadProgress
import com.example.domain.model.ThinkingLevel
import com.example.domain.model.ThinkingSupportMode
import com.example.engine.EngineLifecycleState
import com.example.engine.FinishReason
import com.example.engine.InferenceStreamEvent
import com.example.engine.LocalInferenceEngine
import com.example.engine.PromptFormatter
import com.example.engine.JniLlamaEngineAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class LlamaChatViewModel(application: Application) : AndroidViewModel(application) {

    private val hardwareInspector = DeviceHardwareInspector(application.applicationContext)
    private val storageManager = LocalModelStorageManager(application.applicationContext, viewModelScope)
    private val initialMemory = hardwareInspector.inspectMemoryAndCpu()
    private val repository = GgufRepository(
        defaultThreads = (initialMemory.cpuCores / 2).coerceIn(2, 8),
        localPathResolver = storageManager::getLocalFilePath,
        customFileScanner = storageManager::listCustomStoredFiles,
        customFileInspector = hardwareInspector::inspectLocalModelFile
    )
    private val engine: LocalInferenceEngine = JniLlamaEngineAdapter(application.applicationContext)

    private val currentDestination = MutableStateFlow(AppDestination.CHAT)
    private val composerDraft = MutableStateFlow("")
    private val pendingAttachments = MutableStateFlow<List<ChatAttachment>>(emptyList())
    private val isAttachmentSheetOpen = MutableStateFlow(false)
    private val isContextSheetOpen = MutableStateFlow(false)
    private val isImportingModel = MutableStateFlow(false)
    private val statusBannerMessage = MutableStateFlow<String?>(null)
    private val appliedConfig = MutableStateFlow<InferenceConfig?>(null)

    private var generationJob: Job? = null

    private data class CoreEngineSnapshot(
        val sessions: List<ConversationSession>,
        val activeSessionId: String,
        val models: List<GgufModelSpec>,
        val loadedModel: GgufModelSpec?,
        val appliedConfig: InferenceConfig?,
        val engineState: EngineLifecycleState,
        val config: InferenceConfig,
        val telemetry: EngineTelemetry
    )

    private val coreFlow = combine(
        repository.sessions,
        repository.activeSessionId,
        repository.models,
        engine.loadedModel,
        engine.engineState
    ) { sessions, activeId, models, loaded, state ->
        listOf(sessions, activeId, models, loaded, state)
    }.combine(
        combine(repository.config, engine.telemetry, appliedConfig) { config, telemetry, applied ->
            Triple(config, telemetry, applied)
        }
    ) { base, (config, telemetry, applied) ->
        @Suppress("UNCHECKED_CAST")
        CoreEngineSnapshot(
            sessions = base[0] as List<ConversationSession>,
            activeSessionId = base[1] as String,
            models = base[2] as List<GgufModelSpec>,
            loadedModel = base[3] as GgufModelSpec?,
            appliedConfig = applied,
            engineState = base[4] as EngineLifecycleState,
            config = config,
            telemetry = telemetry
        )
    }

    private data class UiOverlaySnapshot(
        val destination: AppDestination,
        val draft: String,
        val attachments: List<ChatAttachment>,
        val attachmentSheetOpen: Boolean,
        val contextSheetOpen: Boolean,
        val banner: String?,
        val downloads: Map<String, ModelDownloadProgress>,
        val importingModel: Boolean
    )

    private val uiOverlayFlow = combine(
        currentDestination,
        composerDraft,
        pendingAttachments,
        isAttachmentSheetOpen,
        isContextSheetOpen
    ) { dest, draft, attachments, attachSheet, ctxSheet ->
        listOf(dest, draft, attachments, attachSheet, ctxSheet)
    }.combine(
        combine(
            statusBannerMessage,
            storageManager.downloads,
            isImportingModel
        ) { banner, downloads, importing ->
            Triple(banner, downloads, importing)
        }
    ) { items, (banner, downloads, importing) ->
        @Suppress("UNCHECKED_CAST")
        UiOverlaySnapshot(
            destination = items[0] as AppDestination,
            draft = items[1] as String,
            attachments = items[2] as List<ChatAttachment>,
            attachmentSheetOpen = items[3] as Boolean,
            contextSheetOpen = items[4] as Boolean,
            banner = banner,
            downloads = downloads,
            importingModel = importing
        )
    }

    val uiState: StateFlow<LlamaChatUiState> = combine(coreFlow, uiOverlayFlow) { core, ui ->
        LlamaChatUiState(
            currentDestination = ui.destination,
            sessions = core.sessions,
            activeSessionId = core.activeSessionId,
            models = core.models,
            loadedModel = core.loadedModel,
            appliedConfig = core.appliedConfig,
            engineState = core.engineState,
            config = core.config,
            telemetry = core.telemetry,
            deviceMemory = initialMemory,
            downloads = ui.downloads,
            isImportingModel = ui.importingModel,
            composerDraft = ui.draft,
            pendingAttachments = ui.attachments,
            isAttachmentSheetOpen = ui.attachmentSheetOpen,
            isContextSheetOpen = ui.contextSheetOpen,
            statusBannerMessage = ui.banner
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = LlamaChatUiState(
            deviceMemory = initialMemory,
            config = repository.config.value
        )
    )

    fun onAction(action: LlamaChatAction) {
        when (action) {
            is LlamaChatAction.SelectDestination -> currentDestination.value = action.destination
            is LlamaChatAction.UpdateDraft -> composerDraft.value = action.text
            is LlamaChatAction.SendPrompt -> handleSendPrompt(action.overrideText)
            LlamaChatAction.StopGeneration -> handleStopGeneration()
            LlamaChatAction.RegenerateLastResponse -> handleRegenerateLast()

            is LlamaChatAction.LoadModel -> handleLoadModel(action.model)
            LlamaChatAction.ReloadActiveModel -> handleReloadActiveModel()
            LlamaChatAction.UnloadModel -> handleUnloadModel()
            is LlamaChatAction.DownloadModel -> handleDownloadModel(action.model)
            is LlamaChatAction.CancelDownload -> storageManager.cancelDownload(action.modelId)
            is LlamaChatAction.DeleteStoredModel -> handleDeleteStoredModel(action.model)
            is LlamaChatAction.ImportGgufUri -> handleImportModelUri(action.uri)
            LlamaChatAction.RefreshModels -> repository.syncStoredModels()

            LlamaChatAction.ToggleBinaryThinking -> handleToggleBinaryThinking()
            is LlamaChatAction.UpdateThinkingLevel -> repository.updateConfig {
                it.copy(thinkingLevel = action.level)
            }
            is LlamaChatAction.SetAttachmentSheetOpen -> isAttachmentSheetOpen.value = action.open
            is LlamaChatAction.AttachFileUri -> handleAttachFileUri(action.uri, action.isImage)
            is LlamaChatAction.RemovePendingAttachment -> {
                pendingAttachments.update { list -> list.filterNot { it.id == action.attachmentId } }
            }

            LlamaChatAction.CreateNewSession -> {
                if (!uiState.value.isGenerating) {
                    repository.createNewSession(engine.loadedModel.value?.id)
                    currentDestination.value = AppDestination.CHAT
                }
            }
            is LlamaChatAction.SelectSession -> {
                if (!uiState.value.isGenerating) {
                    repository.selectSession(action.sessionId)
                    currentDestination.value = AppDestination.CHAT
                }
            }
            is LlamaChatAction.DeleteSession -> {
                if (!uiState.value.isGenerating) {
                    repository.deleteSession(action.sessionId)
                }
            }

            is LlamaChatAction.SetContextSheetOpen -> isContextSheetOpen.value = action.open
            LlamaChatAction.DismissStatusBanner -> statusBannerMessage.value = null

            // User freely chooses up to the model's real limit without device RAM/CPU caps
            is LlamaChatAction.UpdateContextLength -> repository.updateConfig { current ->
                val maxModelCtx = engine.loadedModel.value?.maxContextLength ?: EngineLimits.DEFAULT_MAX_MODEL_CONTEXT
                val boundedCtx = action.nCtx.coerceIn(EngineLimits.MIN_CONTEXT, maxModelCtx)
                current.copy(contextLength = boundedCtx)
            }
            is LlamaChatAction.UpdateThreads -> repository.updateConfig { current ->
                current.copy(threads = action.threads.coerceIn(EngineLimits.MIN_THREADS, EngineLimits.MAX_THREADS))
            }
            is LlamaChatAction.UpdateBatchSize -> repository.updateConfig { current ->
                current.copy(batchSize = action.nBatch.coerceIn(EngineLimits.MIN_BATCH, EngineLimits.MAX_BATCH))
            }
            is LlamaChatAction.UpdateGpuLayers -> repository.updateConfig { current ->
                current.copy(gpuLayers = action.layers.coerceIn(EngineLimits.MIN_GPU_LAYERS, EngineLimits.MAX_GPU_LAYERS))
            }
            is LlamaChatAction.ToggleMmap -> repository.updateConfig { it.copy(useMmap = action.enabled) }
            is LlamaChatAction.ToggleMlock -> repository.updateConfig { it.copy(useMlock = action.enabled) }
            is LlamaChatAction.UpdateKvCacheQuant -> repository.updateConfig { it.copy(kvCacheQuant = action.quant) }
            is LlamaChatAction.UpdateTemperature -> repository.updateConfig {
                it.copy(temperature = action.temperature.coerceIn(EngineLimits.MIN_TEMP, EngineLimits.MAX_TEMP))
            }
            is LlamaChatAction.UpdateTopP -> repository.updateConfig {
                it.copy(topP = action.topP.coerceIn(0.05f, 1.00f))
            }
            is LlamaChatAction.UpdateTopK -> repository.updateConfig {
                it.copy(topK = action.topK.coerceIn(1, 200))
            }
            is LlamaChatAction.UpdateRepeatPenalty -> repository.updateConfig {
                it.copy(repeatPenalty = action.penalty.coerceIn(0.80f, 2.00f))
            }
            is LlamaChatAction.UpdateMaxTokens -> repository.updateConfig { current ->
                val maxModelCtx = engine.loadedModel.value?.maxContextLength ?: EngineLimits.DEFAULT_MAX_MODEL_CONTEXT
                current.copy(maxTokens = action.maxTokens.coerceIn(EngineLimits.MIN_MAX_TOKENS, maxModelCtx))
            }
            is LlamaChatAction.UpdateSystemPrompt -> repository.updateConfig { it.copy(systemPrompt = action.prompt) }
            LlamaChatAction.ResetDefaultConfig -> {
                repository.updateConfig { InferenceConfig() }
            }
        }
    }

    private fun handleToggleBinaryThinking() {
        val current = repository.config.value.thinkingLevel
        val next = if (current == ThinkingLevel.OFF) ThinkingLevel.HIGH else ThinkingLevel.OFF
        repository.updateConfig { it.copy(thinkingLevel = next) }
    }

    private fun handleAttachFileUri(uri: Uri, isImage: Boolean) {
        isAttachmentSheetOpen.value = false
        if (isImage && engine.loadedModel.value?.supportsVision != true) {
            statusBannerMessage.value = "O modelo atual não oferece suporte a imagens."
            return
        }
        viewModelScope.launch {
            val parsed = withContext(Dispatchers.IO) {
                hardwareInspector.inspectAttachmentUri(uri, forceImage = isImage)
            }
            if (parsed != null) {
                pendingAttachments.update { it + parsed }
            } else {
                statusBannerMessage.value = "Não foi possível anexar o arquivo."
            }
        }
    }

    private fun handleDownloadModel(model: GgufModelSpec) {
        storageManager.startDownload(
            model = model,
            onCompleted = {
                repository.syncStoredModels()
                statusBannerMessage.value = "${model.name} baixado e pronto para carregar."
            },
            onError = { reason ->
                statusBannerMessage.value = reason
            }
        )
    }

    private fun handleDeleteStoredModel(model: GgufModelSpec) {
        viewModelScope.launch {
            if (engine.loadedModel.value?.id == model.id) {
                generationJob?.cancel()
                engine.unloadModel()
                appliedConfig.value = null
            }
            withContext(Dispatchers.IO) {
                storageManager.deleteStoredModel(model.fileName, model.id)
            }
            repository.syncStoredModels()
            statusBannerMessage.value = "${model.name} removido do armazenamento."
        }
    }

    private fun handleImportModelUri(uri: Uri) {
        if (isImportingModel.value) return
        viewModelScope.launch {
            isImportingModel.value = true
            var importFailure: String? = null
            val importedFile = try {
                storageManager.importFromSafUri(uri)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (failure: Exception) {
                importFailure = failure.message
                null
            } finally {
                isImportingModel.value = false
            }
            if (importedFile != null) {
                repository.syncStoredModels()
                val spec = repository.models.value.firstOrNull { it.fileName == importedFile.name }
                statusBannerMessage.value = "${importedFile.name} importado."
                if (spec != null) {
                    handleLoadModel(spec)
                }
            } else {
                statusBannerMessage.value = importFailure
                    ?.let { "Falha ao importar: $it" }
                    ?: "O arquivo selecionado não é um GGUF válido ou não pôde ser copiado."
            }
        }
    }

    private fun handleLoadModel(model: GgufModelSpec) {
        if (uiState.value.isGenerating) {
            statusBannerMessage.value = "Interrompa a geração antes de trocar o modelo."
            return
        }
        viewModelScope.launch {
            repository.updateConfig { current ->
                val defaultThink = when (model.thinkingSupport) {
                    ThinkingSupportMode.NONE -> ThinkingLevel.OFF
                    ThinkingSupportMode.BINARY -> {
                        if (current.thinkingLevel == ThinkingLevel.OFF) ThinkingLevel.OFF else ThinkingLevel.HIGH
                    }
                    ThinkingSupportMode.LEVELS -> {
                        if (current.thinkingLevel == ThinkingLevel.OFF) ThinkingLevel.MEDIUM else current.thinkingLevel
                    }
                }
                // Custom GGUF context limits are unknown until llama.cpp reads their metadata.
                // Keep the user's requested values here; recordAppliedConfig() clamps them
                // against the native training context immediately after a successful load.
                current.copy(thinkingLevel = defaultThink)
            }
            val targetConfig = repository.config.value
            val result = engine.loadModel(model, targetConfig)
            if (result.isSuccess) {
                recordAppliedConfig(targetConfig)
                if (!model.supportsVision) {
                    pendingAttachments.update { list -> list.filterNot { it.isImage } }
                }
                statusBannerMessage.value = "${model.name} carregado."
            } else {
                statusBannerMessage.value = "Falha ao carregar: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    private fun handleReloadActiveModel() {
        val currentModel = engine.loadedModel.value ?: return
        if (uiState.value.isGenerating || uiState.value.isLoadingModel) return

        viewModelScope.launch {
            val targetConfig = repository.config.value
            engine.unloadModel()
            val result = engine.loadModel(currentModel, targetConfig)
            if (result.isSuccess) {
                recordAppliedConfig(targetConfig)
                statusBannerMessage.value = "${currentModel.name} recarregado."
            } else {
                statusBannerMessage.value = "Falha ao recarregar: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    private fun handleUnloadModel() {
        viewModelScope.launch {
            generationJob?.cancel()
            engine.unloadModel()
            appliedConfig.value = null
            statusBannerMessage.value = "Modelo descarregado."
        }
    }

    private fun handleSendPrompt(overrideText: String?) {
        val promptText = (overrideText ?: composerDraft.value).trim()
        val attachments = if (overrideText == null) pendingAttachments.value else emptyList()
        if ((promptText.isBlank() && attachments.isEmpty()) ||
            uiState.value.isGenerating ||
            uiState.value.isLoadingModel
        ) return

        val sessionId = uiState.value.activeSession?.id ?: return
        if (overrideText == null) {
            composerDraft.value = ""
            pendingAttachments.value = emptyList()
        }

        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            role = MessageRole.USER,
            content = promptText,
            attachments = attachments,
            status = MessageStatus.COMPLETED,
            tokenCount = PromptFormatter.estimateTokens(promptText)
        )

        repository.updateSessionMessages(
            sessionId = sessionId,
            autoTitleFromFirstPrompt = promptText.ifBlank { attachments.firstOrNull()?.name ?: "Anexo" },
            attachmentsForTitle = attachments
        ) { current ->
            current + userMessage
        }

        if (engine.loadedModel.value == null) {
            val preferred = repository.models.value.firstOrNull { it.isDownloaded }
            if (preferred != null) {
                viewModelScope.launch {
                    val targetConfig = repository.config.value
                    val res = engine.loadModel(preferred, targetConfig)
                    if (res.isSuccess) {
                        recordAppliedConfig(targetConfig)
                        startStreamingResponse(sessionId)
                    } else {
                        statusBannerMessage.value = "Falha ao carregar ${preferred.name}: ${res.exceptionOrNull()?.message}"
                    }
                }
                return
            }
            statusBannerMessage.value = "Baixe ou importe um modelo GGUF na tela Modelos antes de enviar."
            return
        }

        startStreamingResponse(sessionId)
    }

    private fun handleRegenerateLast() {
        if (uiState.value.isGenerating || uiState.value.isLoadingModel) return
        val session = uiState.value.activeSession ?: return
        val lastUserIndex = session.messages.indexOfLast { it.role == MessageRole.USER }
        if (lastUserIndex == -1) return

        repository.updateSessionMessages(session.id) { messages ->
            messages.take(lastUserIndex + 1)
        }
        startStreamingResponse(session.id)
    }

    private fun startStreamingResponse(sessionId: String) {
        generationJob?.cancel()
        val sessionSnapshot = repository.sessions.value.firstOrNull { it.id == sessionId } ?: return
        val historyForPrompt = sessionSnapshot.messages
        val assistantMsgId = UUID.randomUUID().toString()
        val modelName = engine.loadedModel.value?.name ?: "Ayr off"

        val placeholderAssistant = ChatMessage(
            id = assistantMsgId,
            role = MessageRole.ASSISTANT,
            content = "",
            status = MessageStatus.QUEUED,
            modelName = modelName
        )

        repository.updateSessionMessages(sessionId) { it + placeholderAssistant }

        generationJob = viewModelScope.launch {
            val streamBuffer = StringBuilder()
            var thinkingStartMs = 0L
            var thinkingDurationMs = 0L

            engine.streamCompletion(historyForPrompt, repository.config.value).collect { event ->
                when (event) {
                    is InferenceStreamEvent.Started -> {
                        thinkingStartMs = System.currentTimeMillis()
                        repository.updateSessionMessages(sessionId) { messages ->
                            messages.map { msg ->
                                if (msg.id == assistantMsgId) {
                                    msg.copy(status = MessageStatus.STREAMING)
                                } else msg
                            }
                        }
                    }

                    is InferenceStreamEvent.Token -> {
                        streamBuffer.append(event.text)
                        val latestText = streamBuffer.toString()
                        if (thinkingDurationMs == 0L && latestText.contains("</think>")) {
                            thinkingDurationMs = (System.currentTimeMillis() - thinkingStartMs).coerceAtLeast(100L)
                        }
                        repository.updateSessionMessages(sessionId) { messages ->
                            messages.map { msg ->
                                if (msg.id == assistantMsgId) {
                                    msg.copy(
                                        content = latestText,
                                        status = MessageStatus.STREAMING,
                                        tokenCount = event.totalTokens,
                                        tokensPerSecond = event.tokensPerSecond,
                                        thinkingDurationMs = thinkingDurationMs
                                    )
                                } else msg
                            }
                        }
                    }

                    is InferenceStreamEvent.Completed -> {
                        val finalStatus = when (event.finishReason) {
                            FinishReason.STOPPED_BY_USER -> MessageStatus.STOPPED
                            FinishReason.EOS_TOKEN,
                            FinishReason.MAX_TOKENS,
                            FinishReason.CONTEXT_FULL -> MessageStatus.COMPLETED
                        }
                        repository.updateSessionMessages(sessionId) { messages ->
                            messages.map { msg ->
                                if (msg.id == assistantMsgId) {
                                    msg.copy(
                                        content = streamBuffer.toString().ifBlank { "[Resposta vazia]" },
                                        status = finalStatus,
                                        tokenCount = event.totalTokens,
                                        tokensPerSecond = event.tokensPerSecond,
                                        generationDurationMs = event.durationMs,
                                        thinkingDurationMs = thinkingDurationMs
                                    )
                                } else msg
                            }
                        }
                    }

                    is InferenceStreamEvent.Error -> {
                        repository.updateSessionMessages(sessionId) { messages ->
                            messages.map { msg ->
                                if (msg.id == assistantMsgId) {
                                    msg.copy(
                                        content = event.message,
                                        status = MessageStatus.ERROR
                                    )
                                } else msg
                            }
                        }
                        statusBannerMessage.value = event.message
                    }
                }
            }
        }
    }

    private fun handleStopGeneration() {
        viewModelScope.launch {
            engine.stopGeneration()
        }
    }

    private fun recordAppliedConfig(requested: InferenceConfig) {
        val actualMax = engine.loadedModel.value?.maxContextLength
            ?: EngineLimits.DEFAULT_MAX_MODEL_CONTEXT
        val applied = requested.copy(
            contextLength = requested.contextLength.coerceAtMost(actualMax),
            maxTokens = requested.maxTokens.coerceAtMost(actualMax)
        )
        repository.updateConfig { current ->
            current.copy(
                contextLength = current.contextLength.coerceAtMost(actualMax),
                maxTokens = current.maxTokens.coerceAtMost(actualMax)
            )
        }
        appliedConfig.value = applied
    }

    override fun onCleared() {
        generationJob?.cancel()
        (engine as? java.io.Closeable)?.close()
        super.onCleared()
    }
}
