package com.example.state

import com.example.domain.model.ChatAttachment
import com.example.domain.model.ConversationSession
import com.example.domain.model.DeviceMemoryInfo
import com.example.domain.model.EngineLimits
import com.example.domain.model.EngineTelemetry
import com.example.domain.model.GgufModelSpec
import com.example.domain.model.InferenceConfig
import com.example.domain.model.ModelDownloadProgress
import com.example.engine.EngineLifecycleState

enum class AppDestination {
    CHAT,
    MODELS,
    ENGINE
}

data class LlamaChatUiState(
    val currentDestination: AppDestination = AppDestination.CHAT,
    val sessions: List<ConversationSession> = emptyList(),
    val activeSessionId: String = "",
    val models: List<GgufModelSpec> = emptyList(),
    val loadedModel: GgufModelSpec? = null,
    val appliedConfig: InferenceConfig? = null,
    val engineState: EngineLifecycleState = EngineLifecycleState.UNLOADED,
    val config: InferenceConfig = InferenceConfig(),
    val telemetry: EngineTelemetry = EngineTelemetry(),
    val deviceMemory: DeviceMemoryInfo = DeviceMemoryInfo(
        totalRamMb = 4096,
        availableRamMb = 2048,
        cpuCores = 4,
        primaryAbi = "arm64-v8a",
        isArm64 = true
    ),
    val downloads: Map<String, ModelDownloadProgress> = emptyMap(),
    val isImportingModel: Boolean = false,
    val composerDraft: String = "",
    val pendingAttachments: List<ChatAttachment> = emptyList(),
    val isAttachmentSheetOpen: Boolean = false,
    val isContextSheetOpen: Boolean = false,
    val statusBannerMessage: String? = null
) {
    val activeSession: ConversationSession?
        get() = sessions.firstOrNull { it.id == activeSessionId } ?: sessions.firstOrNull()

    val isGenerating: Boolean
        get() = engineState == EngineLifecycleState.GENERATING

    val isLoadingModel: Boolean
        get() = engineState == EngineLifecycleState.LOADING_MODEL

    val canSendPrompt: Boolean
        get() = (composerDraft.isNotBlank() || pendingAttachments.isNotEmpty()) &&
            !isGenerating &&
            !isLoadingModel

    val maxModelContext: Int
        get() = loadedModel?.maxContextLength ?: EngineLimits.DEFAULT_MAX_MODEL_CONTEXT

    // Thinking level is applied per-prompt without requiring a model reload
    val hasPendingConfigChanges: Boolean
        get() = loadedModel != null &&
            appliedConfig != null &&
            config.copy(thinkingLevel = appliedConfig.thinkingLevel) != appliedConfig
}
